<?php	
$connect = @mysql_connect('localhost','root','') or die(mysql_error()); 
mysql_select_db('data') or die(mysql_error());	
 
 $id =$_GET['id'];
 $result=mysql_query("DELETE FROM noted WHERE no_payment={$id}");
 echo "<script>
	  alert('Confirm Delete?');
	  window.history.back();
	  </script>";
           
	
      
?>