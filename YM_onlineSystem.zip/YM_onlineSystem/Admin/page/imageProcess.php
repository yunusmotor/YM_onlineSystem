<?php
$connect = @mysql_connect('localhost','root','') or die(mysql_error()); 
mysql_select_db('data') or die(mysql_error());	

if (!isset($_FILES['image']['tmp_name'])) {
	echo "";
	}else{
	$file=$_FILES['image']['tmp_name'];
	$image= addslashes(file_get_contents($_FILES['image']['tmp_name']));
	$image_name= addslashes($_FILES['image']['name']);
			
			move_uploaded_file($_FILES["image"]["tmp_name"],"photos/" . $_FILES["image"]["name"]);
			
			$photo="../Admin/page/photos/".$_FILES["image"]["name"];
			$title=$_POST['title'];
			$brand=$_POST['brand'];
            $price=$_POST['price'];
			$Overview=$_POST['Overview'];
			$color1=$_POST['color1'];
			$color2=$_POST['color2'];
			$color3=$_POST['color3'];
			
			
			$save=mysql_query("INSERT INTO product  (title,brand ,image,price,Overview,color1,color2,color3) VALUES ('$title','$brand','$photo','$price','$Overview','$color1','$color2','$color3')");
			 echo "<script>
	 window.history.back();
	  </script>";
			exit();					
	}
?>
