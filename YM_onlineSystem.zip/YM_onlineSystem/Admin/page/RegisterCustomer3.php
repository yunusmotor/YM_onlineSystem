<?php include('../connection.php');
?>

<style type="text/css">
.container .hero-unit-header .container-con .container .row-fluid .span12 .row-fluid .span6 .hero-unit-3 center div form table tr td h4 {
	text-align: center;
}
.container .hero-unit-header .container-con .container .row-fluid .span12 .row-fluid .span6 .hero-unit-3 center div form table tr td table tr td {
}
.container .hero-unit-header .container-con .container .row-fluid .span12 .row-fluid .span6 .hero-unit-3 center div form table tr td table tr td table tr td .control-label {
	font-weight: normal;
}
.red {
	color: #F00;
	font-weight: normal;
}
cc {
	font-weight: normal;
}
.container .hero-unit-header .container-con .container .row-fluid .span12 .row-fluid .span6 .hero-unit-3 center div form table tr td table tr td table tr td .controls .red {
	font-weight: normal;
}
.container .hero-unit-header .container-con .container .row-fluid .span12 .row-fluid .span6 .hero-unit-3 center div form table tr td table tr td table tr td .controls .red {
	font-size: 12px;
}
.container .hero-unit-header .container-con .container .row-fluid .span12 .row-fluid .span6 .hero-unit-3 center div form table tr td table tr td table tr td .controls span {
	color: #F00;
}
</style>
<body>


<div class="container">
<div class="hero-unit-header">
 <div class="container-con">
<!-- end banner & menunav -->

<div class="container">
<div class="row-fluid">
<div class="span12">
<div class="row-fluid">
<div class="span3"></div>
<div class="span6">


<div class="hero-unit-3">
<center>
<div><form  action="../admin/page/RegisterProcessCustomer2.php" method="post" enctype="multipart/form-data" name="addroom">
  <h4>Register Customer</h4>
    <hr>
    <table width="1060" border="0">
      <tr>
        <td width="251"> <h4>Image</h4></td>
        <td width="799">&nbsp;</td>
      </tr>
      <tr>
        <td><center>
          <p><strong>Front IC </strong><br/> 
            <img src="images/default.png" alt="" width="100px" height="100px" style="border:1px solid #333333;">
      </p>
          <div class="control-group">
            <label class="control-label" for="inputPassword"> </label>
            <div class="controls">
              <input type="file" name="image" style="margin-left:0px;">
            </div>
        </div><br/>
          <strong>Rear IC </strong><br/><img src="images/default.png" alt="" width="100px" height="100px" style="border:1px solid #333333;">
          <br/><span class="controls">
            <input type="file" name="image1" style="margin-left:0px;">
          </span><br/>
          </p>
        </center></td>
        <td><table width="668" border="0">
          <tr>
            <td width="662" height="46"><p><strong>Deposit Information:</strong></p>
              <table width="681" border="0">
                <tr>
                  <td width="126">Amount Cash</td>
                  <td width="545"><span class="controls">
                    <input type="text" name="amountCash" required  value="<?php $cash=$_REQUEST["cash"]; echo $cash;?>">
                  </span></td>
                  </tr>
                <tr>
                  <td>Permonthly</td>
                  <td><span class="controls">
                    <input  type="text" name="paymentMonthly" required  value="<?php $permonthly=$_REQUEST["payment"];
echo $permonthly; echo $permonthly; ?>/MONTH">
                    </span>X <span class="controls">
                      <input  type="text" name="month" required  value="<?php $month=$_REQUEST["month"]; echo $month; ?>">
                      </span></td>
                </tr>
                </table>
              <p><br/>
                <strong>Personal Information:</strong></p></td>
            </tr>
          <tr>
            <td><table width="490" border="0">
              <tr>
                <td width="202" height="32"><label class="control-label" for="inputPassword4">Plate No :</label></td>
                <td width="263"><span class="controls">
                  <input type="text" name="plateNo" >
                  <span >*** </span></span></td>
                <td width="11">&nbsp;</td>
                </tr><tr>
                <td width="202" height="32"><label class="control-label" for="inputPassword4">Full Name :</label></td>
                <td width="263"><span class="controls">
                  <input type="text" name="name" required  placeholder="Please input 'Full Name'">
                  <span >*** </span></span></td>
                <td width="11">&nbsp;</td>
                </tr>
              <tr>
                <td height="32"><label class="control-label" for="inputPassword14">Ic No :</label></td>
                <td><span class="controls">
                  <input type="text" name="ic" required placeholder="Please input the number only">
                  <span >*** </span></span></td>
                <td>&nbsp;</td>
                </tr> 
             
              <tr>
                <td height="31"><span class="control-group">
                  <label class="control-label" for="inputPassword6">Gender :</label>
                </span></td>
                <td><span class="controls">
                  <label for="radio">Male</label>
                  <input type="radio" name="gender" id="radio" value="Male">
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label for="radio">Female</label>
                  <input type="radio" name="gender" id="radio" value="Female">
                  
                  </span></td>
                <td>&nbsp;</td>
                </tr>
              <tr>
                <td height="32"><span class="control-group">
                  <label class="control-label" for="inputPassword6">Phone No :</label>
                </span></td>
                <td><span class="controls">
                  <input type="text" name="no" required >
                  <span >***</span></span></td>
                <td>&nbsp;</td>
                </tr>
              <tr>
                <td height="31"><span class="control-group">
                  <label class="control-label" for="inputPassword11">Address:</label>
                </span></td>
                <td><span class="controls">
                  <textarea type="text" name="address" required ></textarea>
                  <span>***</span></span></td>
                <td>&nbsp;</td>
                </tr>
              <tr>
                <td height="35"><span class="control-group">
                  <label class="control-label" for="inputPassword16">Product Supplier Name :</label>
                </span></td>
                <td><span class="controls">
                  <input type="text" name="PSName" required >
                  <span >***</span></span></td>
                <td>&nbsp;</td>
                </tr> <tr>
                  <td height="35">Type Motor:</td>
                  <td><span class="controls">
                    <input type="text" name="typeMotor" required  value="<?php $model=$_REQUEST["model"]; echo $model;?>">
                    <span >***</span></span></td>
                  <td>&nbsp;</td>
                  </tr><tr>
                  <td height="35">No Engine Motor :</td>
                  <td><span class="controls">
                    <input type="text" name="noEngine" required >
                    <span >***</span></span></td>
                  <td>&nbsp;</td>
                  </tr><tr>
                  <td height="35">Color Motor:</td>
                  <td><span class="controls">
                    <input type="text" name="color" required >
                    <span >***</span></span></td>
                  <td>&nbsp;</td>
                  </tr>
              </table></td>
            </tr>
        </table></td>
      </tr>
    </table>
    <div class="control-group">
      <div class="controls">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<center>
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <button type="submit" name="submit" class="btn btn-success" style="margin-right: 30px;">Save</button>
        <button  href="homeAdmin.php?page=reviewWorker" class="btn">Back</button> </center></div>
    </div>
    <p>&nbsp;</p>
  </legend></form></div>
 <form class="form-horizontal" method="post"  enctype="multipart/form-data" style="float: right;" >
                                
                     
                               
                                <hr>
                                <h4>&nbsp;</h4>
                                <hr>
								<div class="control-group">
								  <div class="controls"></div>
                      </div>
								<div class="control-group">
								  <div class="controls"></div>
                                </div>
                                <div class="control-group">
                                  <div class="controls"></div>
                      </div>
                                <div class="control-group">
                                  <div class="controls"></div>
                      </div>
                                <div class="control-group">
                                <div class="controls"></div>
                                      <div class="control-group">
                                    <div class="controls"></div>
                                      <div class="control-group">
                                        <div class="controls"></div>
                      </div>
 </form>
							

							
							
				  </center>
								</center>

				</div>
			  </div>
			</div>
		  </div>
		</div>
	  </div>
	</div>
  </div>
</div>
</body>
</html>
								