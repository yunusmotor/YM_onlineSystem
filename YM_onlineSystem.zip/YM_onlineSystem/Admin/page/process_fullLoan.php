<?php
include "connection.php";

echo "<script>
	  window.location = '../homeAdmin.php?page=RegisterCustomer3';
	  </script>";
?>