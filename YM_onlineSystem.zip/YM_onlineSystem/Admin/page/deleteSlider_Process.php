<?php	
$connect = @mysql_connect('localhost','root','') or die(mysql_error()); 
mysql_select_db('data') or die(mysql_error());	
 
 $id =$_GET['id'];
 $result=mysql_query("DELETE FROM imageslider WHERE id={$id}");
 echo "<script>
	  alert('Confirm Delete Image Slider?');
	  window.history.back();
	  </script>";
           
	
      
?>