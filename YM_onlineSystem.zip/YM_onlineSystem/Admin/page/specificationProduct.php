<?php

include("../connection.php");
 

$getid=$_REQUEST["id"];
$result=mysql_query("SELECT * FROM product WHERE id ='$getid'");
$row=mysql_fetch_array($result);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.black {
	color: #000;
}
.f36 {
	font-size: 24px;
}
</style>
</head>

<body>
<p><?php echo $row['title']; ?><span class="f36">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Price: <?php echo ''.$row['price'].' '; ?></span></p>
<table width="232" border="0">
  <tr>
    <td width="18">&nbsp;</td>
    <td width="204">&nbsp;</td>
  </tr>
  <tr>
    <td><?php echo '<p><img src="'.$row['image'].'"></p>'; ?></td>
    <td>Colors Available:<?php echo '<img src="'.$row['color1'].'">'; ?><?php echo '<img src="'.$row['color2'].'">'; ?><?php echo '<img src="'.$row['color3'].'">'; ?><?php echo '<img src="'.$row['color4'].'">'; ?></td>
  </tr>
  <tr>
    <td  bgcolor=""><p>Overview:</p> <?php echo ''.$row['overview'].' '; ?></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><p>&nbsp;</p>
    <p>Spefication:</p>      <?php echo '<p><img src="'.$row['spefication'].'"></p>'; ?></td>
    <td>&nbsp;</td>
  </tr><tr>
    <td><p>Feature:</p> <?php echo '<p><img src="'.$row['feature'].'"></p>'; ?></td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
