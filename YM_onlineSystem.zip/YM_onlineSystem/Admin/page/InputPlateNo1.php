<?php

include_once("../connection.php");
     

?>
<?php
$query = mysql_query("select * from customer");
?>

<!DOCTYPE HTML>
<html>
<head>
<title>YUNUS MOTOR ONLINE SYSTEM</title>
<link rel='shortcut icon' href='picture/logoym.png' />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
#wrapper #page-wrapper .content_bottom .col-md-8.span_3 .bs-example1 .table {
	color: #000;
}
body,td,th {
	text-decoration: none;
}
body {
	background-color: #000;
}
.style15 {font-size: 24px}
.style1 {
	color: #999;
	font-size: 16px;
}
.style2 {
	color: #000;
	font-size: 18px;
}
.style5 {font-size: 36px;
	font-family: Georgia, "Times New Roman", Times, serif;
}
.style21 {
	color: #000000
}
</style>

</head>
<body><form action="page/searchProcess1.php"  method="post" ><center>
  <table width="708" height="260" border="1" >
         <tr>
           <td width="698" height="254"><table width="697" height="194" border="0">
             <tr>
               <th width="691" height="52" scope="col"><table width="654" class="Left" id="">
                 <tbody>
                   <tr>
                     <td width="183" height="50">&nbsp;</td>
                     <td width="459">
                     </td>
                   </tr>
                   <tr>
                     <td height="30">&nbsp;</td>
                     <td>Plate No. : <span class="style1">                     <input name="txtPlateNo" type="text"
size="20" maxlength="10" value="Search...Plate No." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search...Plate No.';}"/></span> </td>
                   </tr>
                 </tbody>
               </table></th>
             </tr>
             <tr>
               <td height="136"> <center><input class="style2"  name="btnSubmit3" type="submit" value="Search" size="30" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="btnReset2" type="reset" class="style2" value="Reset" size="30"/></</center>&nbsp;</td>
             </tr>
           </table></td>
         </tr>
       </table></center>
     </div>
   </div>
   <!-- /#page-wrapper -->
   </div>
   <hr />
   

</form>
  
</body>
</html>

