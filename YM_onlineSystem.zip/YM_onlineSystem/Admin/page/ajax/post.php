<?php
error_reporting(E_ALL^E_NOTICE);
require "../connect.php";

if(!is_numeric($_POST['zindex']) || !isset($_POST['author']) || !isset($_POST['body']) || !in_array($_POST['color'],array('yellow','white','red','green','blue')))
die("0");

if(ini_get('magic_quotes_gpc'))
{
	$_POST['author']=stripslashes($_POST['author']);
	$_POST['body']=stripslashes($_POST['body']);
}
	$author = mysql_real_escape_string(strip_tags($_POST['author']));
	$body = mysql_real_escape_string(strip_tags($_POST['body']));
	$color = mysql_real_escape_string($_POST['color']);
	$zindex = (int)$_POST['zindex'];

mysql_query('	INSERT INTO messages (text,name,color,xyz)
				VALUES ("'.$body.'","'.$author.'","'.$color.'","0x0x'.$zindex.'")');
if(mysql_affected_rows($link)==1)
{
	echo mysql_insert_id($link);
}
else echo '0';
?>