<?php 
include ('connection.php'); 
include ('header.php'); 
$getid=$_REQUEST["id"];
$result=mysql_query("SELECT * FROM customer WHERE NOPlateMotor ='$getid'");
$row=mysql_fetch_array($result);
?>

<style type="text/css">
body {
	background-color: #000;
}
</style>
<body>




 <form action="../admin/page/updateCustomer_Process1.php" class="form-horizontal" method="post"  enctype="multipart/form-data" style="float: left; font-size: 16px; font-weight: bold;">
                                <legend>
                                Edit Customer Information
                                <table width="577" border="0">
                                  <tr>
                                    <td width="14">&nbsp;</td>
                                    <td width="256"><h4>Image</h4>
                                      <hr>
                                      <div class="control-group">
                                        <label class="control-label" for="inputPassword2">
                                          <b><br>
                                          Front Ic</b><br>
                                          <?php if($row['inFront_IC'] != ""): ?>
                                          <img src="<?php echo $row['inFront_IC']; ?>" alt="" width="100px" height="100px" style="border:1px solid #333333;">
                                          <?php else: ?>
                                          <img src="images/default.png" alt="" width="100px" height="100px" style="border:1px solid #333333;">
                                          <?php endif; ?>
                                        </label>
                                        <p><br/>
                                        <div class="controls">
                                          <input type="file" name="image" style="margin-left:27px; ">
                                        </div>
                                      </div>
                                      <div class="control-group">
                                        <label class="control-label" for="inputPassword2">
                                          <br>
                                          <br>
                                          <b>Rear Ic</b><br>
                                          <?php if($row['Rear_IC'] != ""): ?>
                                          <img src="<?php echo $row['Rear_IC']; ?>" alt="" width="100px" height="100px" style="border:1px solid #333333;">
                                          <?php else: ?>
                                          <img src="images/default.png" alt="" width="100px" height="100px" style="border:1px solid #333333;">
                                          <?php endif; ?>
                                        </label>
                                        <br/>
                                        <div class="controls">
                                          <input type="file" name="image1" style="margin-left:27px; ">
                                        </div>
                                    </div>
                                    <p>&nbsp;</p>
                                    <p>&nbsp;</p>
                                    <p>&nbsp;</p>
                                    <p>&nbsp;</p>
                                    <p>&nbsp;</p>
                                    <p>&nbsp;</p>
                                    <p>&nbsp;</p>
                                    <p>&nbsp;</p></td>
                                    <td width="49">&nbsp;</td>
                                    <td width="221"><div class="control-group"> </div>
                                      <hr>
                                      <h4>Personal Information</h4>
                                      <hr>
                                      <div class="control-group">
                                        <label class="control-label" for="name2"><span class="controls">
                                          <input type="hidden" name="id" required value=<?php echo $row['NOPlateMotor']; ?>>
                                        </span>Plate No:</label>
                                        <div class="controls">
                                          <input type="text" name="NOPlateMotor" required value=<?php echo $row['NOPlateMotor']; ?>>
                                        </div>
                                      </div>
                                      <div class="control-group">
                                        <label class="control-label" for="inputPassword3">Full Name:</label>
                                        <div class="controls">
                                          <input type="text" name="Name_Cust" required value=<?php echo $row['Name_Cust']; ?>>
                                        </div>
                                      </div>
                                      <div class="control-group">
                                        <label class="control-label" for="inputEmail2">Ic No:</label>
                                        <div class="controls">
                                          <input type="text" name="ICNumber_Cust" required value=<?php echo $row['ICNumber_Cust']; ?>>
                                        </div>
                                      </div>
                                      <div class="control-group">
                                        <label class="control-label" for="inputpassword2">Gender:</label>
                                        <div class="controls">
                                          <input type="text" name="genderCust" required value=<?php echo $row['genderCust']; ?>>
                                        </div>
                                      </div>
                                      <div class="control-group">
                                        <label class="control-label" for="inputPassword3">Phone No:</label>
                                        <div class="controls">
                                          <input type="text" name="ContactNO_Cust" required value=<?php echo $row['ContactNO_Cust']; ?>>
                                        </div>
                                      </div>
                                      <div class="control-group">
                                        <label class="control-label" for="inputPassword3">Address:</label>
                                        <div class="controls">
                                          <input type="text" name="Address_Cust" required value=<?php echo $row['Address_Cust']; ?>>
                                        </div>
                                      </div>
                                      <div class="control-group">
                                        <label class="control-label" for="inputPassword3">Product Supplier Name:</label>
                                        <div class="controls">
                                          <input type="text" name="ProductSupplierName" required value=<?php echo $row['ProductSuplierName']; ?>>
                                        </div>
                                      </div>
                                      <div class="control-group">
                                        <label class="control-label" for="inputPassword3">Type Motor:</label>
                                        <div class="controls">
                                          <input type="text" name="TypeMotor" required value=<?php echo $row['TypeMotor']; ?>>
                                        </div>
                                      </div>
                                      <div class="control-group">
                                        <label class="control-label" for="inputPassword3">No Engine Motor:</label>
                                        <div class="controls">
                                          <input type="text" name="No_EngineMotor" required value=<?php echo $row['No_EngineMotor']; ?>>
                                        </div>
                                      </div>
                                      <div class="control-group">
                                        <label class="control-label" for="inputPassword3">Color Motor:</label>
                                        <div class="controls">
                                          <input type="text" name="ColourMotor" required value=<?php echo $row['ColourMotor']; ?>>
                                        </div>
                                      </div>
                                      <div class="control-group">
                                        <div class="controls">
                                          <button action="homeWorker.php?page=reviewAll_Cust1&id=<?php echo $row['NOPlateMotor']?>" type="submit" name="update" class="btn btn-success" style="margin-right: 65px;">Update</button>
                                          <a href="homeWorker.php?page=reviewAll_Cust1" class="btn">Back</a> </div>
                                    </div></td>
                                    <td width="15">&nbsp;</td>
                                  </tr>
                                </table>
                                <h4>&nbsp;</h4></legend>
                                <h4>&nbsp;</h4>
                                
</form>
</body>
</html>
								