<?php include('../connection.php'); ?><head>

       

     
        
		
        <link href="../Admin/modal/css1/bootstrap1.css" rel="stylesheet" type="text/css" media="screen">
     


</head>







<script type="text/javascript" charset="utf-8" language="javascript" src="../Admin/js/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf-8" language="javascript" src="../Admin/js/DT_bootstrap.js"></script>

<style type="text/css">
body {
	background-color: #000000;
	color: #000000;
}
</style>
<body >

<div>    

              <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
                            <div class="alert alert-info">
                               
                              <strong><i class="icon-user icon-large"></i><a href="?page=registerWorker">&nbsp;+Register New Worker</a></strong>
                            </div>
                            <thead>
                                <tr>
                                    <th style="text-align:center;" >Image</th>
                                    <th style="text-align:center;">Full Name</th>
                                    <th style="text-align:center;">Ic No</th>
                                    
                                    
                                    <th style="text-align:center;">Phone No</th>
                                    <th style="text-align:center;">Address</th>
                                    <th style="text-align:center;">Email</th>
									<th style="text-align:center;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
								<?php
								
								$result= mysql_query("select * from staff WHERE level='2' order by staff_id  " ) or die (mysql_error());
								while ($row= mysql_fetch_array ($result) ){
								$id=$row['staff_id'];
								?>
								<tr>
								<td style="text-align:center; margin-top:10px; word-break:break-all; width:100px; line-height:100px;"><a href="#<?php  echo $id;?>" data-toggle="modal">
									<?php if($row['location'] != ""): ?>
									<img src="<?php echo $row['location']; ?>" width="100px" height="100px" style="border:1px solid #333333;">
									<?php else: ?>
									<img src="images/default.png" width="100px" height="100px" style="border:1px solid #333333;">
									<?php endif; ?>
									</a>
								</td>
								<td style="text-align:center; word-break:break-all; width:200px;"> <?php echo $row ['staff_name']; ?></td>
                            
 <td style="text-align:center; word-break:break-all; width:100px;"> <?php echo $row ['staff_ic']; ?></td>
								
                                
								<td style="text-align:center; word-break:break-all; width:100px;"> <?php echo $row ['staff_no']; ?></td>
								<td style="text-align:center; word-break:break-all; width:200px;"> <?php echo $row ['staff_address']; ?></td>
								<td style="text-align:center; word-break:break-all; width:100px;"> <?php echo $row ['staff_email']; ?></td>
								<td style="text-align:center; width:200px;">
									<a href="?page=edit&id=<?php echo $row["staff_id"];?>" class="btn btn-info">Edit</a>
									 <a href="../Admin/page/deleteWorker_Process.php?id= <?php echo $row ['staff_id']; ?>"  data-toggle="modal"  class="btn btn-danger" >Delete </a>
								</td>
									
										<!-- Modal -->
								<div id="delete<?php  echo $id;?>" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
								<div class="modal-header">
								<h3 id="myModalLabel">Delete</h3>
								</div>
								<div class="modal-body">
								<p><div class="alert alert-danger">Are you Sure you want Delete?</p>
								</div>
								<hr>
								<div class="modal-footer">
								<button class="btn btn-inverse" data-dismiss="modal" aria-hidden="true">No</button>
								<a href="delete.php<?php echo '?staff_id='.$id; ?>" class="btn btn-danger">Yes</a>
								</div>
								</div>
								</div>
								</tr>

								<!-- Modal Bigger Image -->
								<div id="<?php  echo $id;?>" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
								<div class="modal-header">

								<h3 id="myModalLabel"><b><?php echo $row['staff_name']." ".$row['staff_username']; ?></b></h3>
								</div>
								<div class="modal-body">
								<?php if($row['location'] != ""): ?>
								<img src="upload/<?php echo $row['location']; ?>" style="width:390px; border-radius:9px; border:5px solid #d0d0d0; margin-left: 63px; height:387px;">
								<?php else: ?>
								<img src="images/default.png" style="width:390px; border-radius:9px; border:5px solid #d0d0d0; margin-left: 63px; height:387px;">
								<?php endif; ?>
								</div>
								<div class="modal-footer">
								<button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
								</div>
								</div>

								<?php } ?>
                            </tbody>
                        </table>


          
       
    </div>


</body>
</html>


