<?php include('../connection.php');?>
<style type="text/css">
.container .hero-unit-header .container-con .container .row-fluid .span12 .row-fluid .span6 .hero-unit-3 center div form table tr td h4 {
	text-align: center;
}
.container .hero-unit-header .container-con .container .row-fluid .span12 .row-fluid .span6 .hero-unit-3 center div form table tr td table tr td {
	font-weight: bold;
}
.container .hero-unit-header .container-con .container .row-fluid .span12 .row-fluid .span6 .hero-unit-3 center div form table tr td table tr td table tr td .control-label {
	font-weight: normal;
}
.red {
	color: #F00;
	font-weight: normal;
}
cc {
	font-weight: normal;
}
.container .hero-unit-header .container-con .container .row-fluid .span12 .row-fluid .span6 .hero-unit-3 center div form table tr td table tr td table tr td .controls .red {
	font-weight: normal;
}
.container .hero-unit-header .container-con .container .row-fluid .span12 .row-fluid .span6 .hero-unit-3 center div form table tr td table tr td table tr td .controls .red {
	font-size: 12px;
}
.star {
	color: #F00;
}
</style>
<body>


<div class="container">
<div class="hero-unit-header">
 <div class="container-con">
<!-- end banner & menunav -->

<div class="container">
<div class="row-fluid">
<div class="span12">
<div class="row-fluid">
<div class="span3"></div>
<div class="span6">


<div class="hero-unit-3">
<center>
<div><form  action="../admin/page/RegisterProcess.php" method="post" enctype="multipart/form-data" name="addroom"><legend><h4>Register New Worker</h4>
    <hr>
    <table width="1060" border="0">
      <tr>
        <td width="245"> <h4>Image</h4></td>
        <td width="805">&nbsp;</td>
      </tr>
      <tr>
        <td><center>
          <img src="images/default.png" width="100px" height="100px" style="border:1px solid #333333;">
          <div class="control-group">
                                  <label class="control-label" for="inputPassword">
										
								  </label>
                                    <div class="controls">
                                        <input type="file" name="image" style="margin-left:27px;">
                                       <br>
                                  </div>
                      </div></center></td>
        <td><table width="506" border="0">
          <tr>
            <td width="500" height="46">Personal Information</td>
          </tr>
          <tr>
            <td><table width="545" border="0">
              <tr>
                <td width="67" height="32">&nbsp;</td>
                <td width="92"><label class="control-label" for="inputPassword4">Full Name:</label></td>
                <td width="355"><span class="controls">
                  <input type="text" name="name" required  placeholder="Please enter full name">
                  </span><span class="star">*** </span></td>
                <td width="13">&nbsp;</td>
              </tr>
              <tr>
                <td height="32">&nbsp;</td>
                <td><label class="control-label" for="inputPassword14">IC Number:</label></td>
                <td><span class="controls">
                  <input type="text" name="ic" required placeholder="Please enter the number only">
                  </span><span class="star">***</span></td>
                <td>&nbsp;</td>
              </tr> <tr>
                <td height="32">&nbsp;</td>
                <td><label class="control-label" for="inputPassword14">Password:</label></td>
                <td><span class="controls">
                  <input type="password" name="password" required >
                  <span class="star">*** </span></span></span></td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td height="32">&nbsp;</td>
                <td><span class="control-label">Username:</span></td>
                <td><span class="controls">
                  <input type="text" name="username" required >
                  <span class="star">*** </span></span></td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td height="31">&nbsp;</td>
                <td><span class="control-group">
                  <label class="control-label" for="inputPassword6">Gender:</label>
                </span></td>
                <td><span class="controls">
                  <label for="radio">Male</label>
                  <input type="radio" name="gender" id="radio" value="Male">
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label for="radio">Female</label>
                  <input type="radio" name="gender" id="radio" value="Female">
                  
                </span></td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td height="32">&nbsp;</td>
                <td><span class="control-group">
                  <label class="control-label" for="inputPassword6">Contact No::</label>
                </span></td>
                <td><span class="controls">
                  <input type="text" name="no" required >
                  <span class="star">*** </span></span></td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td height="31">&nbsp;</td>
                <td><span class="control-group">
                  <label class="control-label" for="inputPassword11">Address::</label>
                  </span></td>
                <td><span class="controls">
                  <input type="text" name="address" required >
                  <span class="star">*** </span></span></td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td height="35">&nbsp;</td>
                <td><span class="control-group">
                  <label class="control-label" for="inputPassword16">Email:</label>
                </span></td>
                <td><span class="controls">
                  <input type="email" name="email" required >
                  <span class="star">*** </span></span></td>
                <td>&nbsp;</td>
              </tr> <tr>
                <td height="35">&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
    </table>
    <div class="control-group">
      <div class="controls">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<center>
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <button type="submit" name="update" class="btn btn-success" style="margin-right: 30px;">Save</button>
        <button  href="homeAdmin.php?page=reviewWorker" class="btn">Back</button> </center></div>
    </div>
    <p>&nbsp;</p>
  </legend></form></div>
 <form class="form-horizontal" method="post"  enctype="multipart/form-data" style="float: right;" >
                                
                     
                               
                                <hr>
                                <h4>&nbsp;</h4>
                                <hr>
								<div class="control-group">
								  <div class="controls"></div>
                      </div>
								<div class="control-group">
								  <div class="controls"></div>
                                </div>
                                <div class="control-group">
                                  <div class="controls"></div>
                      </div>
                                <div class="control-group">
                                  <div class="controls"></div>
                      </div>
                                <div class="control-group">
                                <div class="controls"></div>
                                      <div class="control-group">
                                    <div class="controls"></div>
                                      <div class="control-group">
                                        <div class="controls"></div>
                      </div>
 </form>
							

							
							
				  </center>
								</center>

				</div>
			  </div>
			</div>
		  </div>
		</div>
	  </div>
	</div>
  </div>
</div>
</body>
</html>
								