<?php
$connect = @mysql_connect('localhost','root','') or die(mysql_error()); 
mysql_select_db('data') or die(mysql_error());	

	if (!isset($_FILES['image']['tmp_name'])) {
	echo "";	
	}else{
	$file=$_FILES['image']['tmp_name'];
	$image= addslashes(file_get_contents($_FILES['image']['tmp_name']));
	$image_name= addslashes($_FILES['image']['name']);

	move_uploaded_file($_FILES["image"]["tmp_name"],"photos/" . $_FILES["image"]["name"]);
									$photo="../Admin/page/photos/".$_FILES["image"]["name"];
			
		//	$photo="../Admin/page/photos/".$_FILES["image"]["name"];

			$staff_name=$_POST['name'];
			$staff_ic=$_POST['ic'];
            $staff_password=$_POST['password'];
            $staff_username=$_POST['username']; 		            $staff_gander=$_POST['gender'];
            $staff_no=$_POST['no'];
            $staff_address=$_POST['address']; 		            $staff_email=$_POST['email'];
			
           

			
			$query="INSERT INTO staff  (staff_name,staff_ic ,loginPass,staff_username,staff_gender,staff_no,staff_address,staff_email,location,level) VALUES ('$staff_name','$staff_ic','$staff_password','$staff_username','$staff_gander','$staff_no','$staff_address','$staff_email','$photo','2')";
			$result=mysql_query($query) or die(mysql_error());
			echo "<script>
	  alert('Register worker sussesfully');
	  window.location = '../homeAdmin.php?page=reviewWorker';
	  </script>";
           
	
 exit();	
	
	}
?>
