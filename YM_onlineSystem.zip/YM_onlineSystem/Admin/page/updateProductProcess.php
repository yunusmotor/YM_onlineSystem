<?php
$connect = @mysql_connect('localhost','root','') or die(mysql_error()); 
mysql_select_db('data') or die(mysql_error());	
$getid=$_REQUEST['id'];

			if (!isset($_FILES['image']['tmp_name'])) {
	echo "";	
	}else{
	$file=$_FILES['image']['tmp_name'];
	
	$image_name= addslashes($_FILES['image']['name']);

	move_uploaded_file($_FILES["image"]["tmp_name"],"picture/" . $_FILES["image"]["name"]);
			$photo="../Admin/page/picture/".$_FILES["image"]["name"];
			$id=$_POST['id'];
			$brand=$_POST['brand'];
			$price=$_POST['price'];
			$Overview=$_POST['Overview'];
			
           

			
			mysql_query("UPDATE product SET brand='$brand',title='$brand',price='$price',Overview='$Overview',image='$photo' WHERE id='$id'");
		//	$result=mysql_query or die(mysql_error());
			echo "<script>
	  alert('Update image sussesfully');
	  window.location = '../homeAdmin.php?page=addProduct';
	  </script>";
           
	}
 
	
      
?>
