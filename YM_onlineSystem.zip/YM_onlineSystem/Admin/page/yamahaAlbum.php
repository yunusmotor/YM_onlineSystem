<?php
include('../connection.php');

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.ab {
	font-family: "Arial Black", Gadget, sans-serif;
}
.f16 {
	font-size: 16px;
}
.f24 {
	font-size: 24px;
}
</style>
</head>

<body>
<table width="200" border="0">
  <tr>
    <td colspan="2"><center><img src="../picture/Yamaha-logo.png" width="450" height="150" /></center></td>
  </tr>
  <tr>
    <td colspan="2"><form id="form1" name="form1" method="post" action="">
      <?php
	  $result = mysql_query("SELECT * FROM product WHERE brand='YAMAHA'");
while($row = mysql_fetch_array($result))
{ 
	  ?>
      <table width="108" border="0">
        <tr>
          <td width="17"><?php echo '<p><img src="'.$row['image'].'"></p>'; ?>&nbsp;</td>
          <td width="173"><a href="../Admin/homeAdmin.php?page=specificationProduct&id=<?php echo $row["id"];?>" class="f24" >
            &lt;&lt;Specification
          </a>&nbsp;</td>
        </tr>
        <tr>
          <td><?php echo '<p id="title">'.$row['title'].' </p>'; ?>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
    </table>
    <?php } ?></form>      <form id="form5" name="form5" method="post" action="">
    </form></td>
  </tr>
</table>
</body>
</html>
