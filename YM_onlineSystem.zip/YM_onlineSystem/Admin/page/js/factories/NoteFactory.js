angular.module("noteTaker")
.factory("NoteFactory", function() {
        var allNotes = localStorage.notes || [{title: "Hello", body: "Edit or delete this note and start writing", id:0}];
        if (typeof allNotes === 'string') {
            allNotes = JSON.parse(allNotes);
        }
        return {
            getNotes: allNotes,
            saveNote: function(note) {
                allNotes.push(note);
                localStorage.notes = JSON.stringify(allNotes);
            },
            deleteNote: function(index) {
                var confirmDelete = confirm("Do you really want to delete this note?");
                if (confirmDelete) {
                    allNotes.splice(index,1)
                    localStorage.notes = JSON.stringify(allNotes);
                }
            },
            editNote: function(index, note) {
                allNotes[index] = note;
                localStorage.notes = JSON.stringify(allNotes);
            },
            getNoteText: function(index) {
                var noteParent = document.getElementsByClassName("noteText")[index];
                var title = noteParent.getElementsByTagName("h1")[0].innerText;
                var body = noteParent.getElementsByTagName("p")[0].innerText;
                return {title: title, body: body};
            }
        }
    })