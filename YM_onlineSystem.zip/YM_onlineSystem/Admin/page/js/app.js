angular.module('noteTaker', []);
