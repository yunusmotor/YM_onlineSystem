angular.module("noteTaker")
.controller("NotesController", function($scope, NoteFactory ) {
    $scope.notes = NoteFactory;

    })