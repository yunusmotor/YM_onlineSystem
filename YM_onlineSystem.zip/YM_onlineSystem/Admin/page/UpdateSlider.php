<?php
include_once("function.php");
include("../connection.php");


$getid=$_REQUEST["id"];
$result=mysql_query("SELECT * FROM imageslider WHERE id ='$getid'");
$row=mysql_fetch_array($result);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>YUNUS MOTOR ONLINE SYSTEM</title>
<link rel='shortcut icon' href='picture/logoym.png' />
<style type="text/css">

.col-md-8.span_3 .bs-example1 #addroom p strong {
	font-size: 36px;
	font-weight: bold;
	font-family: "Lucida Console", Monaco, monospace;
}
.col-md-8.span_3 .bs-example1 #addroom p strong {
	color: #F30;
}
.col-md-8.span_3 .bs-example1 strong {
	font-family: "Palatino Linotype", "Book Antiqua", Palatino, serif;
}
body,td,th {
	font-size: 18px;
}
</style>
 
</head>

<body>
<p>&nbsp;</p>
<form action="../admin/page/updateSlider_process.php" method="post" enctype="multipart/form-data" name="addroom" id="addroom">
  <table width="761" height="186" border="0">
    <tr>
      <td width="218" height="182"><table width="326" border="0">
        <tr>
         
          <td width="420"><center>
            <p>Update Slider Image            
            <p><br/><img src= "<?php
		  
 echo $row['image']; ?>" width="455" height="212"/></br>
              <span class="controls">
                <input type="file" name="image" style="margin-left:27px;" />
                </span>
              
              
            </center></td>
         
        </tr>
        <tr>
         
          <td>
            <center>
            </center>
          </td>
          
        </tr>
      </table>
      <p>&nbsp;</p></td>
      <td width="99"><table width="89" border="0">
        <tr>
          <td width="83" height="60">&nbsp;&nbsp;&nbsp;Title&nbsp; &nbsp;&nbsp;:</td>
        </tr>
       
      </table></td>
      <td width="320">
        <table width="435" border="0">
          <tr>
            <td width="232" height="56"><span class="controls">
              <input type="hidden" name="id" required="required" value="<?php echo $row['id']; ?>" />
            </span><span class="controls">
            <input type="text" name="title" required="required" value="<?php echo $row['namePicture']; ?>" />
            </span></td>
             <td width="193"><a href="homeAdmin.php?page=addSlider" class="btn">Back</a><input action=""homeAdmin.php?page=addSlider&id=<?php echo $row['id']?>"" type="submit" name="button" value="Update" style="height:25px; width:75px; background-color:#F30; border:0px solid #333333; border-radius:5px; color:#FFFFFF;" /></td>
          </tr>
         
         
      </table></td>
    </tr>
  </table>
  
  <p>&nbsp;</p>
</form>

<p>&nbsp;</p>
</body>
</html>
