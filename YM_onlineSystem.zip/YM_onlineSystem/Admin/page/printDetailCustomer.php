<?php

 include_once("../connection.php");
     

$getid=$_REQUEST["id"];
$query="SELECT * FROM customer WHERE NOPlateMotor='$getid' ";
$result=mysql_query("SELECT * FROM deposit WHERE NOPlateMotor  ");
$result=mysql_query($query);
$row=mysql_fetch_array($result);


if(!isset($_SESSION['staff_username'])){
    
	die();
}

	   $sql = "SELECT * FROM staff WHERE staff_username='".$_SESSION['staff_username']."'";
        
        $query = mysql_query($sql)
                    or die(mysql_error());
                    
        $results = mysql_fetch_array($query);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.FONT16 {	font-size: 14px;
}
.b {	font-weight: bold;
}
.b {	font-weight: bold;
}
.font {	font-size: 10px;
}
.font {
	font-size: 8px;
}
.font {	font-weight: bold;
}
.font {	font-weight: bold;
}
.font1 {	font-weight: bold;
}
.font1 {	font-weight: bold;
}
.font10 {	font-size: 12px;
	font-weight: bold;
}
.font14 {	font-size: 16px;
}
.font9 {	font-size: 16px;
}
.fontcenter {	text-align: center;
	font-weight: bold;
}
.f14 {
	font-size: 10px;
}
.bfont {
	font-weight: normal;
}
f14 {
	font-size: 14px;
}
bf14 {
	font-size: 14px;
}
.center {	text-align: center;
}
.f141 {
	font-size: 14px;
	text-align: center;
}
.f141 th {
	text-align: center;
}
r {
	text-align: left;
}
.w {
	color: #FFF;
	font-size: 10px;
}
.f12 {
	font-size: 12px;
	color: #FFF;
	text-align: center;
}
.f122 {
	font-size: 12px;
}
.font11 {text-align: center;
	color: #F30;
}
</style>
</head>

<body>
<table width="995" border="0">
  <tr>
    <td width="989">
     <table width="788" border="0">
       <tr>
         <td width="336"><span class="f14">WORKER&nbsp;&nbsp; : <span style="text-align:center; word-break:break-all; width:100px;"><?php echo $results ['staff_name']; ?></span></span></td>
         <td width="202">&nbsp;</td>         
		 <td width="336"><span class="f14">DATE OF PURCASE&nbsp; :<font> <?php echo $row ['date']; ?></span></td>
		 <tr><td width="236"><span class="f14">DATE&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : <?php echo date('d m Y ');?></span></td></tr>
       </tr>
     </table></br>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../picture/logoym1.png" width="91" height="91" />&nbsp;<img src="../picture/nameSystem.png" alt="" width="285" height="20" /><br>
      <table width="657" border="0">
        <tr><center>
         
       </center> </tr>
        <tr><center>
           <td height="14" class="font"><p align="center"><span class="f14">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>LOT  1162,GR.FLOOR,JLN DATUK PENGAIRAN HIPNI 96200 DARO,SARAWAK</p></td></center>
        </tr>
        <tr>
          <td height="10" class="font"><p> <span class="bfont"><span class="f14">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;TEL  &nbsp;&nbsp;&nbsp;&nbsp;: 0198894904 (HP)/084-823835(FAX) </span></span></p></td>
        </tr>
        
      </table><br />
      <table width="837" border="0">
        <tr>
          <td width="831" height="79"><table width="797" border="0">
            <tr>
                <td width="422" height="102"><p><font size="+3"> <?php echo $row ['NOPlateMotor']; ?></font></p>
                  <p>NAME :<?php echo $row['Name_Cust'] ?><br/>
				  NUMBER IC :<?php echo $row['ICNumber_Cust'] ?><br/>
				  CONTACT NUMBER :<?php echo $row['ContactNO_Cust'] ?><br/>
				  Type Motor :<?php echo $row['TypeMotor'] ?><br/>
                    Product Supplier Name :<?php echo $row['ProductSuplierName'] ?><br/>
					ENGINE NO :<?php echo $row['No_EngineMotor'] ?></p></td>
                <td width="365"><table width="323" border="0">
				 <tr>
                    <td width="124" height="28">ADDRESS :</td>
                    <td width="479"><span class="controls"><?php echo $row['Address_Cust'] ?></span></td>
                  </tr>
                  <tr>
                    <td width="134" height="28">Amount Cash:</td>
                    <td width="179"><span class="controls"> RM <?php echo $row['amounthCash'] ?></span></td>
                  </tr>
                  <tr>
                    <td height="34">Deposit</td>
                    <td><span class="controls"> RM <?php echo $row['deposit'] ?></span></td>
                  </tr>
                  <tr>
                    <td height="29">Permonthly</td>
                    <td><span class="controls"> <?php echo $row['paymentMonthly'] ?></span>&nbsp;&nbsp;X <span class="controls"><br/> <?php echo $row['month'] ?></span></td>
                  </tr>
                </table></td>
              </tr>
        </table></td>
        </tr>
        <tr>
          <td><table width="886" border="0">
            <tr>
              <td width="284"><p>&nbsp;</p>
                <p>&nbsp;</p>
                <table width="200" border="0">
                <tr>
                  <td bgcolor="#999999"><img src= "<?php
		  
 echo $row['inFront_IC']; ?>" alt="" width="276" height="150" style="border:1px solid #333333;"/></td>
                </tr>
                <tr>
                  <td>In fron &quot;IC&quot; </td>
                </tr>
                <tr>
                  <td height="41">&nbsp;</td>
                </tr>
                <tr>
                  <td bgcolor="#999999"><img src= "<?php
		  
 echo $row['Rear_IC']; ?>" alt="" width="276" height="150" style="border:1px solid #333333;"/></td>
                </tr>
                <tr>
                  <td></blockquote>
                    </blockquote>
                    Rear &quot;IC&quot;</td>
                </tr>
              </table></td>
              <td width="353"><p>&nbsp;</p>
                <table width="100%"  class="table-striped table-bordered">
                <thead>
                  <tr>
                    <th width="19%" height="35">Monthly</th>
                    <th width="26%">Plate No.</th>
                    <th width="27%">Date</th>
                    <th width="28%">Amount</th>
                    </tr>
                </thead>
                <tbody>
                  <?php 
							$query=mysql_query("select * from deposit where NOPlateMotor='$getid'  ORDER BY date DESC")or die(mysql_error());
							while($row=mysql_fetch_array($query)){
							$id=$row['no_Payment'];
							?>
                  <tr id="row1">
                    <td><input type="hidden" name="id" value="<?php echo $row['no_Payment'] ?>"/>
                      <?php echo $row['perMonth'] ?></td>
                    <td><?php echo $row['NOPlateMotor'] ?></td>
                    <td><?php echo $row['date'] ?></td>
                    <td>RM<?php echo $row['amount'] ?></td>
                    </tr>
                  <?php } ?>
                </tbody>
              </table>
               <br/> <?php
                 
								
                            $result1 = mysql_query("SELECT sum(amount) FROM deposit WHERE NOPlateMotor='$getid'") or die(mysql_error()); 
							
                            while ($rows1 = mysql_fetch_array($result1)) {
                                ?>
                           
        <div class="pull-right">
          <div class="span">
            <div class="alert alert-info"><i class="icon-credit-card icon-large"></i>&nbsp;Total Amount : RM&nbsp;<?php echo $rows1['sum(amount)']; ?></div>
          </div>
        </div>
         
        
                              <?php
                 
								
                            $result2 = mysql_query("SELECT paymentMonthly,month FROM customer WHERE NOPlateMotor='$getid'") or die(mysql_error()); 
							
                            while ($rows2 = mysql_fetch_array($result2)) {
                                ?>
                            <div class="pull-right">
          <div class="span">
            <div class="alert alert-info"><i class="icon-credit-card icon-large"></i>&nbsp;Remainder : RM&nbsp;<?php  $balance=$rows2['paymentMonthly']*$rows2['month'];
			$amount=$rows1['sum(amount)'];
			$total=$balance - $amount;
			echo $total;
		?></div>
          </div>
        </div> <?php }?> <?php }
                            ?></td><td width="62"><p>&nbsp;</p>
        </p></td><td width="116"><p>
          <input type="submit" name="button" id="button" value="Print" onclick="print()" />
          <a href=" <?php echo "<script>
	  window.history.back();
	  </script>"; ?>"  data-toggle="modal"  class="btn-success" >Back </a>
          </p>
        </p></td>
            </tr>
          </table></td>
        </tr>
      </table>
      <br></td>
  </tr>
</table></center>
</body>
</html>
