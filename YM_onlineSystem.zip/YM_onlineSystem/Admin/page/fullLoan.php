<?php 
include_once("../connection.php");




?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body><form method="post" action="homeAdmin.php?page=RegisterCustomer3">
<table  align="center">
  <tr style="height:200px; width:1020px">
    <td width="368"align="center"  style=" width:255px; border:0px solid #0000CC;" ><div style="height:400px; width:830px; float:left;border:1px solid #B9B9B9;border-radius:10px; margin-left:12px; margin-top:20px;"><br/>
    <strong>FULL LOAN</strong><br/>
      <br/>
      <br/>
      <table width="200" border="0">
        <tr>
          <td><table width="449" border="0"><tr>
              <td width="136">Model</td>
              <td width="92">&nbsp;</td>
              <td width="207"><input name="model" type="text" id="model" /></td>
            </tr><tr>
              <td width="136">Amount Cash</td>
              <td width="92">&nbsp;</td>
              <td width="207">
                <input name="cash" type="text" id="cash" />
              </td>
            </tr><tr>
              <td width="136">Payment Permonth</td>
              <td width="92">&nbsp;</td>
              <td width="207"><label>
                <input name="payment" type="text" id="peyment" />
                /
              (1.60%)</label></td>
            </tr>
            <tr>
              <td>Monthly Payment</td>
              <td>&nbsp;</td>
              <td><span style="color:darkblue">
                <select name="month" id="month">
                  <option>12( 1 Year )</option>
                  <option>18( 1 1/2 Year )</option>
                  <option>24 ( 2 Year )</option>
                  <option>30 ( 2 1/2 Year )</option>
                  <option>36 ( 3 Year )</option>
                  <option>42 ( 3 1/2 Year )</option>
                  <option>48 ( 4 Year )</option>
                </select>
              </span></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td height="78">&nbsp;</td>
              <td><input type="reset" name="button2" id="button2" value="Clear" style="height:25px; width:75px; background-color:#CC0; border:0px solid #333333; border-radius:5px; color:#FFFFFF;" /></td>
              <td>
                <input type="submit" name="button3" id="button" value="Add" style="height:25px; width:75px; background-color:#000000; border:0px solid #333333; border-radius:5px; color:#FFFFFF;" />
              </td>
            </tr>
          </table></td>
          <td><img src="../picture/ABSTRACT.PNG" width="260" height="168" /></td>
        </tr>
      </table>
      <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
    </div></td>
  </tr>
</table>
</form>
</body>
</html>
