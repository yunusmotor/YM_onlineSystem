<?php
$connect = @mysql_connect('localhost','root','') or die(mysql_error()); 
mysql_select_db('data') or die(mysql_error());	
$getid=$_REQUEST['id'];

			if (!isset($_FILES['image']['tmp_name'])) {
	echo "";	
	}else{
	$file=$_FILES['image']['tmp_name'];
	
	$image_name= addslashes($_FILES['image']['name']);

	move_uploaded_file($_FILES["image"]["tmp_name"],"images/" . $_FILES["image"]["name"]);
			$photo="../Admin/page/images/".$_FILES["image"]["name"];
			$id=$_POST['id'];
			$title=$_POST['title'];
			
           

			
			mysql_query("UPDATE imageslider SET namePicture='$title',image='$photo' WHERE id='$id'");
		//	$result=mysql_query or die(mysql_error());
			echo "<script>
	  alert('Update image sussesfully');
	  window.location = '../homeAdmin.php?page=addSlider';
	  </script>";
           
	}
 
	
      
?>
