<?php
$connect = @mysql_connect('localhost','root','') or die(mysql_error()); 
mysql_select_db('data') or die(mysql_error());	
$getid=$_REQUEST['id'];

if (!isset($_FILES['image']['tmp_name'])) {
	echo "";	
	}else{
	$file=$_FILES['image']['tmp_name'];
	$image= addslashes(file_get_contents($_FILES['image']['tmp_name']));
	$image_name= addslashes($_FILES['image']['name']);
	$image_name1= addslashes($_FILES['image1']['name']);	
			move_uploaded_file($_FILES["image"]["tmp_name"],"photos/" . $_FILES["image"]["name"]);
			
		
			$image1="../Admin/page/photos/".$_FILES["image"]["name"];
			$image2="../Admin/page/photos/".$_FILES["image1"]["name"];
			
			$id=$_POST['id'];
            $NOPlateMotor=$_POST['NOPlateMotor'];
			$Name_Cust=$_POST['Name_Cust'];
            $ICNumber_Cust=$_POST['ICNumber_Cust'];
            $genderCust=$_POST['genderCust']; 		
            $ContactNO_Cust=$_POST['ContactNO_Cust'];
            $Address_Cust=$_POST['Address_Cust'];
            $ProductSupplierName=$_POST['ProductSupplierName'];
            $TypeMotor=$_POST['TypeMotor'];
            $No_EngineMotor=$_POST['No_EngineMotor'];
            $ColourMotor=$_POST['ColourMotor'];
	$date=$_POST['date'];
	$amounthCash=$_POST['amounthCash'];
	$deposit=$_POST['deposit'];
	$paymentMonthly=$_POST['paymentMonthly'];
	$month=$_POST['month'];

           

			
			mysql_query("UPDATE customer SET inFront_IC='$image1',Rear_IC='$image2',NOPlateMotor='$NOPlateMotor',Name_Cust='$Name_Cust',
ICNumber_Cust='$ICNumber_Cust',genderCust='$genderCust',ContactNO_Cust='$ContactNO_Cust',Address_Cust='$Address_Cust',ProductSuplierName='$ProductSupplierName',
TypeMotor='$TypeMotor',No_EngineMotor='$No_EngineMotor',ColourMotor='$ColourMotor',date='$date',amounthCash='$amounthCash',deposit='$deposit',paymentMonthly='$paymentMonthly',month='$month' WHERE NOPlateMotor='$id'");
		//	$result=mysql_query or die(mysql_error());
			echo "<script>
	  alert('Update successfully');
	  window.location = '../homeAdmin.php?page=reviewAll_Cust';
	  </script>";
           
	}
 
	
      
?>