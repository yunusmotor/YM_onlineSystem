<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">

.col-md-8.span_3 .bs-example1 #addroom p strong {
	font-size: 36px;
	font-weight: bold;
	font-family: "Lucida Console", Monaco, monospace;
}
.col-md-8.span_3 .bs-example1 #addroom p strong {
	color: #F30;
}
</style>
 
</head>

<body>
<div class="col-md-8 span_3">
  <div class="bs-example1" data-example-id="contextual-table">
    <form action="modData.php" method="post" name="TambahMotor" id="TambahMotor">
      <br />
      <br />
      <br />
      <center>
        <h1>Tambah Motor </h1>
      </center>
      <table width="397" height="186" border="0" class="editMotor" >
        <tr>
          <td width="103">Kode Motor</td>
          <td width="278"><label for="txtKodeMotor"></label>
            <input name="txtKodeMotor" type="text" id="txtKodeMotor" value="<?php echo $data['KodeMotor']; ?>" /></td>
        </tr>
        <tr>
          <td>Merek</td>
          <td><input name="txtMerek" type="text" id="txtMerek" /></td>
        </tr>
        <tr>
          <td>Warna</td>
          <td><input name="txtWarna" type="text" id="txtWarna" /></td>
        </tr>
        <tr>
          <td>Harga</td>
          <td><input name="txtHarga" type="text" id="txtHarga" /></td>
        </tr>
        <tr>
          <td colspan="2" align="center"><input type="submit" name="btn_simpan" id="button" value="Simpan" class="btn_simpan" /></td>
        </tr>
      </table>
    </form>
    <p>&nbsp;</p>
  </div>
</div>
</body>
</html>
