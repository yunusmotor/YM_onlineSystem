
<?php

include_once("../connection.php");
     

$getid=$_REQUEST["id"];
$query="SELECT * FROM customer WHERE NOPlateMotor='$getid'";
$result=mysql_query("SELECT * FROM deposit WHERE NOPlateMotor");
$result=mysql_query($query);
$row=mysql_fetch_array($result);


          
	
 
	
      
?>


 <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
 <style type="text/css">
 #price {margin-top: 5px;
}
#title {margin-top: 5px;
}


a:hover {
	text-decoration: underline;
}


a:visited {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
 </style>
<body>

<table width="921" border="0">

  <tr>
    <td width="915">
     <div class="">
        <div class="alert alert-success">Deposit By Monthly Payment</div>
        <table width="681" border="0">
          <tr>
            <td width="126">Amount Cash</td>
            <td width="545"><span class="controls">
             RM <?php echo $row['amounthCash'] ?> 
            </span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $row['date'] ?> </td>
          </tr>
          <tr>
            <td>Deposit</td>
            <td><span class="controls">
             RM <?php echo $row['deposit'] ?>
            </span></td>
          </tr>
          <tr>
            <td>Permonthly</td>
            <td><span class="controls">
             RM<?php echo $row['paymentMonthly'] ?>
              </span>X <span class="controls">
                <?php echo $row['month'] ?>
              </span></td>
          </tr>
        </table>
        <br /><form action="../Admin/page/addDeposit_process.php" method="post">
      <table width="918" border="0">
        <tr>
          <td width="206">Plate No: &nbsp;</td>
          <td width="301">Monthly &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date</td>
          <td width="397">Amount</td>
          </tr>
        <tr>
          <td><input name="platenumber" value="<?php echo $row['NOPlateMotor'] ?>" size="7" readonly/></td>
          <td>
            <input name="monthly" type="text"   id="textfield" placeholder="Monthly" size="5">
          &nbsp;&nbsp;&nbsp;&nbsp;
          <input name="date" type="date"   id="date"  size="5"></td>
          <td>RM
            <input name="amount" type="text" id="textfield3" onKeyPress='return event.charCode >=48 && event.charCode <=57' placeholder="Amount" size="10">
            <input name="button" type="submit" class="tooltip-inner" id="button" value="+ADD" data-toggle="modal"></td>
          </tr>
      </table></form>
      <p>&nbsp;  </p>
     
        <table width="87%"  class="table table-striped table-bordered">
          <thead>
            <tr>
              <th width="7%">Monthly</th>
              <th width="14%">Plate No.</th>
              <th width="17%">Date</th>
              <th width="15%">Amount</th>
              <th width="27%">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php 
							$query=mysql_query("select * from deposit where NOPlateMotor='$getid' ORDER BY date DESC")or die(mysql_error());
							while($row=mysql_fetch_array($query)){
							$id=$row['no_Payment'];
							?>
            <tr id="row1">
              <td><input type="hidden" name="id" value="<?php echo $row['no_Payment'] ?>"/>                <?php echo $row['perMonth'] ?></td>
              <td><?php echo $row['NOPlateMotor'] ?></td>
              <td><?php echo $row['date'] ?></td>
              <td>RM<?php echo $row['amount'] ?></td>
              <td><a href="../print_page.php?id=<?php echo $row["no_Payment"];?>?remainder=<?php  
			echo $_SESSION['remainder'];
							?>"  data-toggle="modal"  class="btn-success" >Print Resit </a> &nbsp;&nbsp;&nbsp;&nbsp;<a href="../Admin/page/deleteDeposit_Process.php?id= <?php echo $row ['no_Payment']; ?>"  data-toggle="modal"  class="tooltip-inner" >Delete </a></td>
            </tr>
            <?php } ?>
          </tbody>
        </table>
          
        
        <?php
                            $result = mysql_query("SELECT sum(perMonth) FROM deposit WHERE NOPlateMotor='$getid'") or die(mysql_error());
                            while ($rows = mysql_fetch_array($result)) {
                                ?>
        <?php }
                            ?>
                            
        <?php
                 
								
                            $result1 = mysql_query("SELECT sum(amount) FROM deposit WHERE NOPlateMotor='$getid'") or die(mysql_error()); 
							
                            while ($rows1 = mysql_fetch_array($result1)) {
                                ?>
                           
        <div class="pull-right">
          <div class="span">
            <div class="alert alert-info"><i class="icon-credit-card icon-large"></i>&nbsp;Total Amount : RM&nbsp;<?php echo $rows1['sum(amount)']; ?></div>
          </div>
        </div>
         
        
                              <?php
                 
								
                            $result2 = mysql_query("SELECT paymentMonthly,month FROM customer WHERE NOPlateMotor='$getid'") or die(mysql_error()); 
							
                            while ($rows2 = mysql_fetch_array($result2)) {
                                ?>
                            <div class="pull-right">
          <div class="span">
            <div class="alert alert-info"><i class="icon-credit-card icon-large"></i>&nbsp;Remainder : RM&nbsp;<?php  $balance=$rows2['paymentMonthly']*$rows2['month'];
			$amount=$rows1['sum(amount)'];
			$total=$balance - $amount;
			echo $total;
			$_SESSION['remainder']=$total;
		?></div>
          </div>
        </div> <?php }?> <?php }
                            ?>
  </div>
      <p>&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;  &nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp;<br />
      </p>
    </form></td>
  </tr>
</table>
<br>
</body>
</html>
