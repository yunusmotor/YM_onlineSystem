<?php include('../connection.php'); ?><head>

       

     
        
		
        <link href="../Admin/modal/css1/bootstrap1.css" rel="stylesheet" type="text/css" media="screen">
     


</head>







<script type="text/javascript" charset="utf-8" language="javascript" src="../Admin/js/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf-8" language="javascript" src="../Admin/js/DT_bootstrap.js"></script>

<style type="text/css">
body {
	background-color: #000000;
	color: #000000;
}
</style>
<body >

<div>    

              <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
                            <div class="alert alert-info">
                               
                              <strong><i class="icon-user icon-large"></i><a href="?page=registerCustomer4">&nbsp;+Add New Customer</a></strong>
                            </div>
                            <thead>
                                <tr>
                                    <th style="text-align:center;" >ID Card</th>
                                    <th style="text-align:center;">No Plate Motor</th>
                                    <th style="text-align:center;">Full Name</th>
                                    
                                    
                                    <th style="text-align:center;">IC No</th>
                                    <th style="text-align:center;">Phone No</th>
                                    <th style="text-align:center;">Address </th>
									<th style="text-align:center;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
								<?php
								
								$result= mysql_query("select * from customer order by NOPlateMotor " ) or die (mysql_error());
								while ($row= mysql_fetch_array ($result) ){
								$id=$row['NOPlateMotor'];
								?>
								<tr>
								<td style="text-align:center; margin-top:10px; word-break:break-all; width:100px; line-height:100px;"><a href="#<?php  echo $id;?>" data-toggle="modal">
									<?php if($row['inFront_IC'] != ""): ?>
									<img src= "<?php echo $row['inFront_IC']; ?>" width="230" height="100px" style="border:1px solid #333333;">
									<?php else: ?>
									<img src="images/default.png" width="233" height="100px" style="border:1px solid #333333;">
									<?php endif; ?>
									</a>
								</td>
								<td style="text-align:center; word-break:break-all; width:200px;"> <?php echo $row ['NOPlateMotor']; ?></td>
                            
 <td style="text-align:center; word-break:break-all; width:100px;"> <?php echo $row ['Name_Cust']; ?></td>
								
                                
								<td style="text-align:center; word-break:break-all; width:100px;"> <?php echo $row ['ICNumber_Cust']; ?></td>
								<td style="text-align:center; word-break:break-all; width:200px;"> <?php echo $row ['ContactNO_Cust']; ?></td>
								<td style="text-align:center; word-break:break-all; width:100px;"> <?php echo $row ['Address_Cust']; ?></td>
								<td style="text-align:center; width:200px;">
									<a href="?page=edit_Customer1&id=<?php echo $row["NOPlateMotor"];?>" class="btn btn-info">Edit</a>
									 <a href="../Admin/page/deleteCustomer_Process.php?id=<?php echo $row ['NOPlateMotor']; ?>"  data-toggle="modal"  class="btn btn-danger" >Delete </a>
								</td>
									
										<!-- Modal -->
								<div id="delete<?php  echo $id;?>" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
								<div class="modal-header">
								<h3 id="myModalLabel">Delete</h3>
								</div>
								<div class="modal-body">
								<p><div class="alert alert-danger">Are you Sure you want Delete?</p>
								</div>
								<hr>
								<div class="modal-footer">
								<button class="btn btn-inverse" data-dismiss="modal" aria-hidden="true">No</button>
								<a href="delete.php<?php echo '?NOPlateMotor='.$id; ?>" class="btn btn-danger">Yes</a>
								</div>
								</div>
								</div>
								</tr>

								<!-- Modal Bigger Image -->
								<div id="<?php  echo $id;?>" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
								<div class="modal-header">

								<h3 id="myModalLabel"><b><?php echo $row['Name_Cust']." ".$row['Name_Cust']; ?></b></h3>
								</div>
								<div class="modal-body">
								<?php if($row['location'] != ""): ?>
								<img src="upload/<?php echo $row['inFront_IC']; ?>" style="width:390px; border-radius:9px; border:5px solid #d0d0d0; margin-left: 63px; height:387px;">
								<?php else: ?>
								<img src="images/default.png" style="width:390px; border-radius:9px; border:5px solid #d0d0d0; margin-left: 63px; height:387px;">
								<?php endif; ?>
								</div>
								<div class="modal-footer">
								<button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
								</div>
								</div>

								<?php } ?>
                            </tbody>
                        </table>


          
       
    </div>


</body>
</html>
