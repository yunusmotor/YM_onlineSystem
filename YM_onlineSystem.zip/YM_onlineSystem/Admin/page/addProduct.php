<style type="text/css">
<!--
.ed{
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
margin-bottom: 4px;
}
#button1{
text-align:center;
font-family:Arial, Helvetica, sans-serif;
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
background-color:#00CCFF;
height: 34px;
}
#imagelist{
border: thin solid silver;
float:left;
padding:5px;
width:auto;
margin: 0 5px 0 0;
}
p{
	margin: 0;
	padding: 0;
	text-align: left;
	font-style: italic;
	font-size: 16px;
	text-indent: 0;
}
#title{
margin-top: 5px;
}
#price{
margin-top: 5px;
}
img{
	height: 20px;
}
hr{height:0; border:none; border-bottom:1px solid rgba(255,255,255,0.13); border-top:1px solid rgba(0,0,0,1); margin:9px 10px; clear:both;}
.e {
	text-align: left;
}
-->
</style>

<form action="../admin/page/imageProcess.php" method="post" enctype="multipart/form-data" name="addroom">
  <p>Add New Product</p>
  <hr />
  <p>&nbsp;</p>
  <table width="851" border="0">
    <tr>
      <td width="297">Select Image: <br />
      <input type="file" name="image" class="ed" /></td>
      <td width="544">&nbsp;</td>
    </tr>
    <tr>
      <td height="92"><p>Model<br />
        <input name="title" type="text" class="ed" id="title" />
        </p>
        <p>&nbsp;</p>
        <p>Brand<br />
          <label for="select7" ></label >
          <select class="ed" name="brand" size="1" id="brand">
            <option value="YAMAHA">YAMAHA</option>
            <option value="HONDA">HONDA</option>
            <option value="SYM">SYM</option>
            <option value="MODENAS">MODENAS</option>
            <option value="DEMAK">DEMAK</option>
          </select>
        </p>
        <p>&nbsp;</p>
        <p>Price <br />
          <input name="price" type="text" class="ed" id="price" />
      </p></td>
      <td><p >Choose colour available..</p>
        <p >&nbsp;</p>
        <p >Colour1</p>
        <p ><br />
          <input type="radio"  name="color1" id="radio" value="../colour/black.PNG" />
          &quot;Black&quot;
          &nbsp;&nbsp;<img src="../colour/black.PNG" width="35" height="18" /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <input type="radio" name="color1" id="radio2" value="../colour/red.PNG" />
          &quot;Red&quot; &nbsp;&nbsp;&nbsp;<img src="../colour/red.PNG" alt="" width="35" height="18" /> &nbsp;<span class="e">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span class="e">
          <input type="radio" name="color1" id="radio5" value="../colour/pupple.PNG" />
&quot;Pupple&quot; <img src="../colour/pupple.PNG" alt="" width="35" height="18" />&nbsp; </span></p>
        <p class="e">&nbsp;</p>
        <p class="e">
          <input type="radio" name="color1" id="radio3" value="../colour/blue.PNG" />
          &quot;Blue&quot; &nbsp;&nbsp;&nbsp;&nbsp;<img src="../colour/blue.PNG" alt="" width="35" height="18" /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <input type="radio" name="color1" id="radio4" value="../colour/white.PNG" />
        &quot;White&quot; <img src="../colour/white.PNG" alt="" width="35" height="18" /> &nbsp;</p></td>
    </tr>
    <tr>
      <td><p>Overview</p>
      <p>
        <textarea saiz="50" name="Overview" type="text" class="ed" id="Overview" /></textarea>
      </p></td>
      <td><p class="e">&nbsp;</p>
        <p >Colour2</p>
        <p ><br />
          <input type="radio" name="color2" id="radio6" value="../colour/black.PNG" />
  &quot;Black&quot;
          &nbsp;&nbsp;<img src="../colour/black.PNG" alt="" width="35" height="18" /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <input type="radio" name="color2" id="radio7" value="../colour/red.PNG" />
  &quot;Red&quot; &nbsp;&nbsp;&nbsp;<img src="../colour/red.PNG" alt="" width="35" height="18" /> &nbsp;<span class="e">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span class="e">
  <input type="radio" name="color2" id="radio8" value="../colour/pupple.PNG" />
  &quot;Pupple&quot; <img src="../colour/pupple.PNG" alt="" width="35" height="18" />&nbsp; </span></p>
        <p class="e">&nbsp;</p>
        <p class="e">
          <input type="radio" name="color2" id="radio9" value="../colour/blue.PNG" />
  &quot;Blue&quot; &nbsp;&nbsp;&nbsp;&nbsp;<img src="../colour/blue.PNG" alt="" width="35" height="18" /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <input type="radio" name="color2" id="radio10" value="../colour/white.PNG" />
  &quot;White&quot; <img src="../colour/white.PNG" alt="" width="35" height="18" /> &nbsp;</p>
        <p class="e">&nbsp;</p></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><p >&nbsp;</p>
        <p >Colour3</p>
        <p ><br />
          <input type="radio" name="color3" id="radio11" value="../colour/black.PNG" />
  &quot;Black&quot;
          &nbsp;&nbsp;<img src="../colour/black.PNG" alt="" width="35" height="18" /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <input type="radio" name="color3" id="radio12" value="../colour/red.PNG" />
  &quot;Red&quot; &nbsp;&nbsp;&nbsp;<img src="../colour/red.PNG" alt="" width="35" height="18" /> &nbsp;<span class="e">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span class="e">
  <input type="radio" name="color3" id="radio13" value="../colour/pupple.PNG" />
  &quot;Pupple&quot; <img src="../colour/pupple.PNG" alt="" width="35" height="18" />&nbsp; </span></p>
        <p class="e">&nbsp;</p>
        <p class="e">
          <input type="radio" name="color3" id="radio14" value="../colour/blue.PNG" />
  &quot;Blue&quot; &nbsp;&nbsp;&nbsp;&nbsp;<img src="../colour/blue.PNG" alt="" width="35" height="18" /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <input type="radio" name="color3" id="radio15" value="../colour/white.PNG" />
  &quot;White&quot; <img src="../colour/white.PNG" alt="" width="35" height="18" /> &nbsp;</p></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="Submit" value="Upload" id="button1" /></td>
    </tr>
  </table>
  <p><br /><br />
  </p>
  <p><br />
  </p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
<p><br />
PRODUCT MOTORCYCLE</p>
<hr />
<center>
  <img src='../picture/Yamaha-logo.png' alt="" width="183" height="59"  id="image2" style="width:200px;height:56px;" border="0" />
</center><br />
YAMAHA<br />
<br />
<?php
include('../connection.php');

$result = mysql_query("SELECT * FROM product WHERE brand='YAMAHA'");
while($row = mysql_fetch_array($result))
{

echo '<div id="imagelist">';
echo '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="?page=updateProduct&id='. $row["id"].'"><img src="../picture/edit.png" alt=""id="image2" style="width:70px;height:26px;" border="0" /></a>';
echo "&nbsp;<a href='../Admin/page/deleteProduct_Process.php?id= ".$row ['id']. "' ><font size='7' color='#FF0000'>X</font></a>";
echo '<p><img style="width:260px;height:206px;" src="'.$row['image'].'"></p>';
echo '<p id="brand">'.$row['brand'].' </p>';
echo '<p id="title">'.$row['title'].' </p>';
echo '<p id="price">'.$row['price'].' </p>';
echo '</div>';
}
?>
<hr />
<center>
<img src='../picture/sym-logo.png' alt="" width="183" height="59"  id="image2" style="width:200px;height:56px;" border="0" /></center><br />
SYM<br />
<br />
<?php
include('../connection.php');

$result = mysql_query("SELECT * FROM product WHERE brand='SYM'");
while($row = mysql_fetch_array($result))
{
echo '<div id="imagelist">';
echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='../Admin/page/deleteProduct_Process.php?id= ".$row ['id']. "' ><font size='7' color='#FF0000'>X</font></a>";
echo '<p><img style="width:260px;height:206px;"  src="'.$row['image'].'"></p>';
echo '<p id="brand">'.$row['brand'].' </p>';
echo '<p id="title">'.$row['title'].' </p>';
echo '<p id="price">'.$row['price'].' </p>';
echo '</div>';
}
?>
<hr />
<center>
<img src='../picture/Honda-logo.png' alt="" width="183" height="59"  id="image2" style="width:200px;height:56px;" border="0" /></center><br /> 
HONDA
<br />
<br />
<?php
include('../connection.php');

$result = mysql_query("SELECT * FROM product WHERE brand='HONDA'");
while($row = mysql_fetch_array($result))
{
echo '<div id="imagelist">';
echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='../Admin/page/deleteProduct_Process.php?id= ".$row ['id']. "' ><font size='7' color='#FF0000'>X</font></a>";
echo '<p><img style="width:260px;height:206px;"  src="'.$row['image'].'"></p>';
echo '<p id="brand">'.$row['brand'].' </p>';
echo '<p id="title">'.$row['title'].' </p>';
echo '<p id="price">'.$row['price'].' </p>';
echo '</div>';
}
?>
<hr />
<center>
<img src='../picture/Modenas-logo.png' alt="" width="183" height="59"  id="image2" style="width:200px;height:56px;" border="0" /></center>
MODENAS<br />
<br />
<?php
include('../connection.php');

$result = mysql_query("SELECT * FROM product WHERE brand='MODENAS'");
while($row = mysql_fetch_array($result))
{
echo '<div id="imagelist">';
echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='../Admin/page/deleteProduct_Process.php?id= ".$row ['id']. "' ><font size='7' color='#FF0000'>X</font></a>";
echo '<p><img style="width:260px;height:206px;"   src="'.$row['image'].'"></p>';
echo '<p id="brand">'.$row['brand'].' </p>';
echo '<p id="title">'.$row['title'].' </p>';
echo '<p id="price">'.$row['price'].' </p>';
echo '</div>';
}
?>
<hr />
<center>
<img src='../picture/Demak-logo.png' alt="" width="183" height="59"  id="image2" style="width:200px;height:56px;" border="0" /></center><br /> 
DEMAK
<br />
<br />
<?php
include('../connection.php');

$result = mysql_query("SELECT * FROM product WHERE brand='DEMAK'");
while($row = mysql_fetch_array($result))
{
echo '<div id="imagelist">';
echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='../Admin/page/deleteProduct_Process.php?id= ".$row ['id']. "' ><font size='7' color='#FF0000'>X</font></a>";
echo '<p><img style="width:260px;height:206px;"  src="'.$row['image'].'"></p>';
echo '<p id="brand">'.$row['brand'].' </p>';
echo '<p id="title">'.$row['title'].' </p>';
echo '<p id="price">'.$row['price'].' </p>';
echo '</div>';
}
?>
