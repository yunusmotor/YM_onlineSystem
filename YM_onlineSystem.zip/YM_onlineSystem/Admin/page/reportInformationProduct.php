<?php

 


if(!isset($_SESSION['staff_username'])){
    
	die();
}

	   $sql = "SELECT * FROM staff WHERE staff_username='".$_SESSION['staff_username']."'";
        
        $query = mysql_query($sql)
                    or die(mysql_error());
                    
        $results = mysql_fetch_array($query);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.FONT16 {	font-size: 14px;
}
.b {	font-weight: bold;
}
.b {	font-weight: bold;
}
.font {	font-size: 10px;
}
.font {
	font-size: 10px;
}
.font {	font-weight: bold;
}
.font {	font-weight: bold;
}
.font1 {	font-weight: bold;
}
.font1 {	font-weight: bold;
}
.font10 {	font-size: 12px;
	font-weight: bold;
}
.font14 {	font-size: 16px;
}
.font9 {	font-size: 16px;
}
.fontcenter {	text-align: center;
	font-weight: bold;
}
.f14 {
	font-size: 10px;
}
.bfont {
	font-weight: normal;
}
f14 {
	font-size: 14px;
}
bf14 {
	font-size: 14px;
}
.center {	text-align: center;
}
.f141 {
	font-size: 14px;
	text-align: center;
	color: #FFF;
}
.f141 th {
	text-align: center;
}
r {
	text-align: left;
}
</style>
</head>

<body><center>
<table width="630" border="0">
  <tr>
    <td width="624"><center>
     <table width="992" border="0">
       <tr>
         <td width="399"><span class="f14">WORKER&nbsp;&nbsp; : <span style="text-align:center; word-break:break-all; width:100px;"><?php echo $results ['staff_name']; ?></span></span></td>
         <td width="382">&nbsp;</td>
         <td width="197"><span class="f14">DATE&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : <?php echo date('d m Y ');?></span></td>
       </tr>
     </table>
     <img src="../picture/logoym.png" width="122" height="54" />&nbsp;<img src="../picture/nameSystem.png" alt="" width="285" height="20" /><br>
      <table width="456" border="0">
        <tr><center>
          <td width="450" height="33"><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><span class="f14">&nbsp;</span><img src="../picture/Yamaha-logo.png" width="58" height="32" alt="logoyamaha" /><img src="../picture/sym-logo.png" width="55" height="33" alt="logosym" /><img src="../picture/Honda-logo.png" width="54" height="33" alt="logohonda" /><img src="../picture/Modenas-logo.png" width="51" height="31" alt="logomodenas" /><img src="../picture/Demak-logo.png" width="52" height="33" alt="logoyamaha" /></td>
       </center> </tr>
        <tr><center>
           <td height="31" class="font"><p align="center">LOT  1162,GR.FLOOR,JLN DATUK PENGAIRAN HIPNI 96200 DARO,SARAWAK</p></td></center>
        </tr>
        <tr>
          <td height="10" class="font"><p> <span class="bfont"><span class="f14">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;TEL  &nbsp;&nbsp;&nbsp;&nbsp;: 0198894904 (HP)/084-823835(FAX) </span></span></p></td>
        </tr>
        
      </table><br />
      <table width="89%" border="1" >
        <thead>
          <tr class="f141">
            <th width="12%" bgcolor="#000000">ID</th>
            <th width="20%" bgcolor="#000000">Brand</th>
            <th width="47%" bgcolor="#000000">Model</th>
            <th width="21%" bgcolor="#000000">Price</th>
          </tr>
        </thead>
        <tbody>
          <?php 
							$query=mysql_query("select * from product ORDER BY id DESC")or die(mysql_error());
							while($row=mysql_fetch_array($query)){
							
							?>
          <tr class="left" id="row1">
            <td bgcolor="#FFFFFF"><center><?php echo $row['id'] ?></center></td>
            <td bgcolor="#FFFFFF"><?php echo $row['brand'] ?></td>
            <td bgcolor="#FFFFFF"><?php echo $row['title'] ?></td>
            <td bgcolor="#FFFFFF"><?php echo $row['price'] ?></td>
          </tr>
          <?php } ?>
        </tbody>
      </table>
      <br>
        <input type="submit" name="button" id="button" value="Print" onclick="print()" />
      </p>
    </center></td>
  </tr>
</table></center>
</body>
</html>
