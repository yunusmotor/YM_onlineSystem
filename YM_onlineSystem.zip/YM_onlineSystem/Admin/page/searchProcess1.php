<?php
include_once("../../connection.php");
     


$getId=$_POST["txtPlateNo"];

$query="SELECT NOPlateMotor FROM customer WHERE NOPlateMotor='$getId'";
$result=mysql_query($query);
$count=mysql_num_rows($result);
if($count==0)
{

    echo "<script>
	  alert('No information found!!! .Click ..OK.. to try again.');
	  window.location = '../homeAdmin.php?page=InputPlateNo';
	  </script>
	  ";
}
else
{

    $row=mysql_fetch_array($result);
	header("location:../homeWorker.php?page=deposit_Bymonthly&id=$row[NOPlateMotor]");
}
?>
