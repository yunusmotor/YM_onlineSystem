<?php
include_once("function.php");
include("../connection.php");
if(!isset($_SESSION['staff_username'])){
    
	die();
}

	   $sql = "SELECT * FROM staff WHERE staff_username='".$_SESSION['staff_username']."'";
        
        $query = mysql_query($sql)
                    or die(mysql_error());
                    
        $results = mysql_fetch_array($query);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>YUNUS MOTOR ONLINE SYSTEM</title>
<link rel='shortcut icon' href='picture/logoym.png' />
<style type="text/css">

.col-md-8.span_3 .bs-example1 #addroom p strong {
	font-size: 36px;
	font-weight: bold;
	font-family: "Lucida Console", Monaco, monospace;
}
.col-md-8.span_3 .bs-example1 #addroom p strong {
	color: #F30;
}
.col-md-8.span_3 .bs-example1 strong {
	font-family: "Palatino Linotype", "Book Antiqua", Palatino, serif;
}
body,td,th {
	font-size: 18px;
}
</style>
 
</head>

<body>
<table width="998" border="0">
  <tr>
    <td width="1005" bgcolor="#999999"><p><strong><center><b>Yunus Motor Online System</b></center></strong></p></td>
  </tr>
</table>
<p>&nbsp;</p>
<form action="../admin/page/updateAdmin_process.php" method="post" enctype="multipart/form-data" name="addroom" id="addroom">
  <p><strong>Welcome
    
  </strong></p>
  <table width="761" height="186" border="0">
    <tr>
      <td width="218" height="182"><table width="200" border="0">
        <tr>
         
          <td width="158"><center>
            <p><img src= "<?php
		  
 echo $results['location']; ?>" width="155" height="212"/></br>
            <span class="controls">
            <input type="file" name="image" style="margin-left:27px;" />
            </span>
            
            
          </center></td>
         
        </tr>
        <tr>
         
          <td>
            <center>
            </center>
          </td>
          
        </tr>
      </table>
      <p>&nbsp;</p></td>
      <td width="99"><table width="129" border="0">
        <tr>
          <td width="123" height="60">&nbsp;&nbsp;&nbsp;Full Name&nbsp; &nbsp;&nbsp;:</td>
        </tr>
        <tr>
          <td height="61">&nbsp;&nbsp;&nbsp;IC Number &nbsp;:</td>
        </tr>
        <tr>
          <td height="59">&nbsp;&nbsp;&nbsp;Username&nbsp;&nbsp;&nbsp;&nbsp;:</td>
        </tr>
        <tr>
          <td height="60">&nbsp;&nbsp;&nbsp;Password :</td>
        </tr> <tr>
          <td height="60">&nbsp;&nbsp;&nbsp;Phone No :</td>
        </tr>
        <tr>
          <td height="63">&nbsp;&nbsp;&nbsp;Gender&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :</td>
        </tr><tr>
          <td height="63">&nbsp;&nbsp;&nbsp;Email&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :</td>
        </tr>
        <tr>
          <td height="67">&nbsp;&nbsp;&nbsp;Address &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</td>
        </tr>
      </table></td>
      <td width="320">
        <table width="435" border="0">
          <tr>
            <td width="232" height="56"><span class="controls">
              <input type="hidden" name="id" required="required" value="<?php echo $results['staff_id']; ?>" />
            </span><span class="controls">
            <input type="text" name="staff_name" required="required" value="<?php echo $results['staff_name']; ?>" />
            </span></td>
          </tr>
          <tr>
            <td height="55"><span class="controls">
              <input type="text" name="staff_ic" required="required" value="<?php echo $results['staff_ic']; ?>" />
            </span></td>
          </tr>
          <tr>
            <td height="60"><span class="controls">
              <input type="text" name="staff_username" required="required" value="<?php echo $results['staff_username']; ?>" />
            </span></td>
          </tr>
          <tr>
            <td height="59"><span class="controls">
              <input type="password" name="staff_password" required="required" value="<?php echo $results['loginPass']; ?>" />
            </span></td>
          </tr> <tr>
            <td height="59"><span class="controls">
              <input type="text" name="staff_no" required="required" value="<?php echo $results['staff_no']; ?>" />
            </span></td>
          </tr>
          <tr>
            <td height="73">
                <input type="text" name="staff_gender" required="required" value="<?php echo $results['staff_gender']; ?>" />
            </td>
          </tr> <tr>
            <td height="73">
                <input type="email" name="staff_email" required="required" value="<?php echo $results['staff_email']; ?>" />
            </td>
          </tr>
          <tr>
            <td height="58"><span class="controls">
              <te type="text" name="staff_address" required="required" value="<?php echo $results['staff_address']; ?>" />
              <input type="text" name="staff_address" required="required" value="<?php echo $results['staff_address']; ?>" />
            </span></td><td width="193"><a href="homeAdmin.php?page=review_admin" class="btn">Back</a><input action=""homeAdmin.php?page=reviewAdmin&id=<?php echo $results['staff_id']?>"" type="submit" name="button" value="Save" style="height:25px; width:75px; background-color:#F30; border:0px solid #333333; border-radius:5px; color:#FFFFFF;" /></td>
          </tr>
      </table></td>
    </tr>
  </table>
  
  <p>&nbsp;</p>
</form>

<p>&nbsp;</p>
</body>
</html>
