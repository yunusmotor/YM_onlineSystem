<?php

$connect = @mysql_connect('localhost','root','') or die(mysql_error()); 
mysql_select_db('data') or die(mysql_error());	

if (!isset($_FILES['image']['tmp_name'])) {
	echo "";	
	}else{
	$file=$_FILES['image']['tmp_name'];
	$image= addslashes(file_get_contents($_FILES['image']['tmp_name']));
	$image_name= addslashes($_FILES['image']['name']);
	$image_name1= addslashes($_FILES['image1']['name']);	
			move_uploaded_file($_FILES["image"]["tmp_name"],"photos/" . $_FILES["image"]["name"]);
			move_uploaded_file($_FILES["image1"]["tmp_name"],"photos/" . $_FILES["image1"]["name"]);
		
			$image1="../Admin/page/photos/".$_FILES["image"]["name"];
			$image2="../Admin/page/photos/".$_FILES["image1"]["name"];
			
			
			  
			$amounthCash=$_POST['amountCash'];
			$deposit=$_POST['deposit'];
            $paymentMonthly=$_POST['paymentMonthly'];
			$month=$_POST['month'];
            $plateNo=$_POST['plateNo'];
			$name=$_POST['name'];
            $ic=$_POST['ic'];
            $gender=$_POST['gender']; 		
            $no=$_POST['no'];
            $address=$_POST['address'];
            $PSName=$_POST['PSName'];
            $typeMotor=$_POST['typeMotor'];
            $noEngine=$_POST['noEngine'];
            $color=$_POST['color'];
$date=$_POST['date'];
			
          


  
			$query="INSERT INTO customer  (inFront_IC,Rear_IC,amounthCash,deposit,paymentMonthly,month,NOPlateMotor,Name_Cust,ICNumber_Cust,genderCust,ContactNO_Cust,Address_Cust,ProductSuplierName,TypeMotor,No_EngineMotor,ColourMotor,date) VALUES ('$image1','$image2','$amounthCash','$deposit','$paymentMonthly','$month','$plateNo','$name','$ic','$gender','$no','$address','$PSName','$typeMotor','$noEngine','$color','$date')";
      
			
			$result=mysql_query($query) or die(mysql_error());
			echo "<script>
	  alert('Register Customer succesfully');
	  window.location = '../homeAdmin.php?page=reviewAll_Cust';
	  </script>";
            
				

	
	}
?>
