<?php	
$connect = @mysql_connect('localhost','root','') or die(mysql_error()); 
mysql_select_db('data') or die(mysql_error());	
$noplat=$_POST['platenumber'];
$monthly=$_POST['monthly'];
$date=$_POST['date'];
$amount=$_POST['amount'];

$query="INSERT INTO deposit  (NOPlateMotor,perMonth,date ,amount) VALUES ('$noplat','$monthly','$date','$amount')";
			$result=mysql_query($query) or die(mysql_error());
 echo "<script>
	 window.history.back();
	  </script>";		
           
exit();	
 
	
      
?>
