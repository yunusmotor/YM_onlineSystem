<?php 
include ('connection.php'); 
include ('header.php'); 
$getid=$_REQUEST["id"];
$result=mysql_query("SELECT * FROM staff WHERE staff_id ='$getid'");
$row=mysql_fetch_array($result);
?>
<style type="text/css">
body {
	background-color: #000;
}
</style>
<body>


<div class="container">
<div class="hero-unit-header">
 <div class="container-con">
<!-- end banner & menunav -->

<div class="container">
<div class="row-fluid">
<div class="span12">
<div class="row-fluid">
<div class="span3"></div>
<div class="span6">


<div class="hero-unit-3">
<center>

 <form action="../admin/page/updateWorker_process.php" class="form-horizontal" method="post"  enctype="multipart/form-data" style="float: right;">
                                <legend><h4>Edit</h4></legend>
                                <h4>Image</h4>
                                <hr>
								<div class="control-group">
                                    <label class="control-label" for="inputPassword">
										<?php if($row['location'] != ""): ?>
										<img src="<?php echo $row['location']; ?>" width="100px" height="100px" style="border:1px solid #333333;">
										<?php else: ?>
										<img src="images/default.png" width="100px" height="100px" style="border:1px solid #333333;">
										<?php endif; ?>
									</label>
                                    <div class="controls">
                                        <input type="file" name="image" style="margin-left:27px; ">
										
                                    </div>
                                </div>
                                <hr>
                                <h4>Personal Information</h4>
                                <hr>
								<div class="control-group">
                                    <label class="control-label" for="name"><span class="controls">
                                     
                                      <input type="hidden" name="id" required value=<?php echo $row['staff_id']; ?>>
                                    </span>Full Name:</label>
                                    <div class="controls">
                                        <input type="text" name="staff_name" required value=<?php echo $row['staff_name']; ?>>
                                    </div>
                                </div>
								<div class="control-group">
                                    <label class="control-label" for="inputPassword">Ic No:</label>
                                    <div class="controls">
                                        <input type="text" name="staff_ic" required value=<?php echo $row['staff_ic']; ?>>
                                    </div>
                                </div>
                                <div class="control-group">
                                    <label class="control-label" for="inputEmail">Username:</label>
                                    <div class="controls">
                                        <input type="text" name="staff_username" required value=<?php echo $row['staff_username']; ?>>
                                    </div>
                                </div>
                                <div class="control-group">
                                    <label class="control-label" for="inputpassword">Password:</label>
                                    <div class="controls">
                                        <input type="password" name="staff_password" required value=<?php echo $row['loginPass']; ?>>
                                    </div>
                                </div>
                                <div class="control-group">
                                    <label class="control-label" for="inputPassword">Gender:</label>
                                    <div class="controls">
                                        <input type="text" name="staff_gender" required value=<?php echo $row['staff_gender']; ?>>
                                    </div>
                                </div>
                                <div class="control-group">
                                    <label class="control-label" for="inputPassword">Phone No.:</label>
                                    <div class="controls">
                                        <input type="text" name="staff_no" required value=<?php echo $row['staff_no']; ?>>
                                    </div>
                                      <div class="control-group">
                                    <label class="control-label" for="inputPassword">Address.:</label>
                                    <div class="controls">
                                        <input type="text" name="staff_address" required value=<?php echo $row['staff_address']; ?>>
                                    </div>
                                      <div class="control-group">
                                    <label class="control-label" for="inputPassword">Email:</label>
                                    <div class="controls">
                                        <input type="email" name="staff_email" required value=<?php echo $row['staff_email']; ?>>
                                    </div>
                                </div>
								
								 <div class="control-group">
                                    <div class="controls">

                                        <button action="homeAdmin.php?page=reviewWorker&id=<?php echo $row['staff_id']?>" type="submit" name="update" class="btn btn-success" style="margin-right: 65px;">Update</button>
										<a href="homeAdmin.php?page=reviewWorker" class="btn">Back</a>
                                    </div>
                                </div>
                            </form>
							

								</center>
								</center>

								</div>
								</div>
								</div>
								</div>
								</div>
								</div>
								</div>
								</div>
								</div>
</body>
</html>
								