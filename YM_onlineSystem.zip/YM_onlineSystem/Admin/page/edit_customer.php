<?php 
include ('connection.php'); 

$getid=$_REQUEST["id"];
$result=mysql_query("SELECT * FROM customer WHERE NOPlateMotor ='$getid'");
$row=mysql_fetch_array($result);
?>

<style type="text/css">
body {
	background-color: #000;
}
</style>
<body>




 <form action="../admin/page/updateCustomer_Process.php" class="form-horizontal" method="post"  enctype="multipart/form-data" >
                                <legend>
                                Edit Customer Information
                                <table width="477" border="0">
                                  <tr>
                                    <td width="10">&nbsp;</td>
                                    <td width="156"><h4>Image</h4>
                                      <hr>
                                      <div class="control-group">
                                        <label class="control-label" for="inputPassword2">
                                          <b><br>
                                          Infront Ic</b><br>
                                          <?php if($row['inFront_IC'] != ""): ?>
                                          <img src="<?php echo $row['inFront_IC']; ?>" alt="" width="270px" height="170px" style="border:1px solid #333333;">
                                          <?php else: ?>
                                          <img src="images/default.png" alt="" width="270px" height="170px" style="border:1px solid #333333;">
                                          <?php endif; ?>
                                        </label>
                                        <p><br/>
                                        <div class="controls">
                                         
                                          <input type="file" name="image" style="margin-left:27px; ">
                                          <input type="hidden" name="image" value=<?php echo $row['Rear_IC']; ?> style="margin-left:27px; ">                                  
                                          
                                        </div>
                                      </div>
                                      <div class="control-group">
                                        <label class="control-label" for="inputPassword2">
                                          <br>
                                          <br>
                                          <b>Rear Ic</b><br>
                                          <?php if($row['Rear_IC'] != ""): ?>
                                          <img src="<?php echo $row['Rear_IC']; ?>" alt="" width="270px" height="170px" style="border:1px solid #333333;">
                                          <?php else: ?>
                                          <img src="images/default.png" alt="" width="270px" height="170px" style="border:1px solid #333333;">
                                          <?php endif; ?>
                                        </label>
                                        <br/>
                                        <div class="controls">
						<input type="file" name="image1"   style="margin-left:27px; ">
                                          <input type="hidden" name="image1"  value=<?php echo $row['Rear_IC']; ?> style="margin-left:27px; ">
                                        </div>
                                    </div>
                                    <p>&nbsp;</p>
                                    <p>&nbsp;</p>
                                    <p>&nbsp;</p>
                                    <p>&nbsp;</p>
                                    <p>&nbsp;</p>
                                    <p>&nbsp;</p>
                                    <p>&nbsp;</p>
                                    <p>&nbsp;</p></td>
                                    <td width="49">&nbsp;</td>
                                    <td width="421"><div class="control-group"> </div>
                                      <hr>
                                      <h4>Personal Information</h4>
                                      <hr>
                                      <div class="control-group">
                                        <label class="control-label" for="name2"><span class="controls">
                                          <input type="hidden" name="id" required value=<?php echo $row['NOPlateMotor']; ?>>
                                        </span>Plate No:</label>
                                        <div class="controls">
                                          <input  name="NOPlateMotor" required value=<?php echo $row['NOPlateMotor']; ?>>
                                        </div>
                                      </div>
                                      
<div class="control-group">
                                        <label class="control-label" for="inputEmail2">
                                        Full Name:</label>
                                        <div class="controls"> 
                                         
                                       <textarea name="Name_Cust" required
   rows="1" cols="35"><?php echo $row['Name_Cust']; ?></textarea>
                                      </div></div>
                                      <div class="control-group">
                                        <label class="control-label" for="inputEmail2">Ic No:</label>
                                        <div class="controls">
                                          <input  name="ICNumber_Cust" required value=<?php echo $row['ICNumber_Cust']; ?>>
                                        </div>
                                      </div>
                                      <div class="control-group">
                                        <label class="control-label" for="inputpassword2">Gender:</label>
                                        <div class="controls">
                                          <input  name="genderCust" required value=<?php echo $row['genderCust']; ?>>
                                        </div>
                                      </div>
                                      <div class="control-group">
                                        <label class="control-label" for="inputPassword3">Phone No:</label>
                                        <div class="controls">
                                        
<textarea name="ContactNO_Cust" required
   rows="1" cols="35"><?php echo $row['ContactNO_Cust']; ?></textarea>
                                        </div>
                                      </div>
                                      <div class="control-group">
                                        <label class="control-label" for="inputPassword3">Address:</label>
                                        <div class="controls"><textarea name="Address_Cust" required
   rows="5" cols="35"><?php echo $row['Address_Cust']; ?></textarea>
                                          
                                        </div>
                                      </div>
                                      <div class="control-group">
                                        <label class="control-label" for="inputPassword3">Product Supplier Name:</label>
                                        <div class="controls"><textarea name="ProductSupplierName" required
   rows="1" cols="35"><?php echo $row['ProductSuplierName']; ?></textarea>
                                          
                                        </div>
                                      </div>
                                      <div class="control-group">
                                        <label class="control-label" for="inputPassword3">Type Motor:</label>
                                        <div class="controls"><textarea name="TypeMotor" required
   rows="1" cols="35"><?php echo $row['TypeMotor']; ?></textarea>
                                         
                                        </div>
                                      </div>
                                      <div class="control-group">
                                        <label class="control-label" for="inputPassword3">No Engine Motor:</label>
                                        <div class="controls">
                                          <input  name="No_EngineMotor" required value=<?php echo $row['No_EngineMotor']; ?>>
                                        </div>
                                      </div>
                                      <div class="control-group">
                                        <label class="control-label" for="inputPassword3">Color Motor:</label>
                                        <div class="controls">
                                          <input  name="ColourMotor" required value=<?php echo $row['ColourMotor']; ?>>
                                        </div>
                                      </div>

 <div class="control-group">
                                        <label class="control-label" for="inputPassword3">Date:</label>
                                        <div class="controls">
                                          <input type="date" name="date" required value=<?php echo $row['date']; ?>>
                                        </div>
                                      </div>     
 <div class="control-group">
                                        <label class="control-label" for="inputPassword3">Amounth Cash:</label>
                                        <div class="controls"><textarea name="amounthCash" required
   rows="1" cols="20"><?php echo $row['amounthCash']; ?></textarea>
                                         
                                        </div>
                                      </div>     
<div class="control-group">
                                        <label class="control-label" for="inputPassword3">Deposit:</label>
                                        <div class="controls"><textarea name="deposit" required
   rows="1" cols="20"><?php echo $row['deposit']; ?></textarea>
                                         
                                        </div>
                                      </div> 
<div class="control-group">
                                        <label class="control-label" for="inputPassword3">PerMonth:</label>
                                        <div class="controls"><textarea name="paymentMonthly" required
   rows="1" cols="20"><?php echo $row['paymentMonthly']; ?></textarea>
                                         
                                        </div>
                                      </div> 
<div class="control-group">
                                        <label class="control-label" for="inputPassword3">Month:</label>
                                        <div class="controls"><textarea name="month" required
   rows="1" cols="20"><?php echo $row['month']; ?></textarea>
                                         
                                        </div>
                                      </div>                                   <div class="control-group">
                                        <div class="controls">
                                          <button action="homeAdmin.php?page=reviewAll_Cust&id=<?php echo $row['NOPlateMotor']?>" type="submit" name="update" class="btn btn-success" style="margin-right: 65px;">Update</button>
                                          <a href="homeAdmin.php?page=reviewAll_Cust" class="btn">Back</a> </div>
                                    </div></td>
                                    <td width="15">&nbsp;</td>
                                  </tr>
                                </table>
                                <h4>&nbsp;</h4></legend>
                                <h4>&nbsp;</h4>
                                
</form>
</body>
</html>
								