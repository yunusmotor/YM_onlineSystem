<?php 

include('../connection.php');

$get_id=$_GET['staff_id'];

mysql_query("delete from staff where staff_id = '$get_id' ")or die(mysql_error());
header('location:homeAdmin.php?page=reviewWorker');
?>