
<?php
$connect = @mysql_connect('localhost','root','');
mysql_select_db('data');
$result = mysql_query("SELECT * FROM images WHERE url");
while($row = mysql_fetch_array($result))
{
echo '<div id="imagelist">';
echo '<p><img src="'.$row['url'].'"></p>';
echo '</div>';
}
?>

