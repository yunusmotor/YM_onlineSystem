<style type="text/css">
<!--
.ed{
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
margin-bottom: 4px;
}
#button1{
text-align:center;
font-family:Arial, Helvetica, sans-serif;
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
background-color:#00CCFF;
height: 34px;
}
#imagelist{
border: thin solid silver;
float:left;
padding:5px;
width:auto;
margin: 0 5px 0 0;
}
p{
margin:0;
padding:0;
text-align: center;
font-style: italic;
font-size: smaller;
text-indent: 0;
}
#title{
margin-top: 5px;
}
#price{
margin-top: 5px;
}
img{
height: 225px;
}
hr{height:0; border:none; border-bottom:1px solid rgba(255,255,255,0.13); border-top:1px solid rgba(0,0,0,1); margin:9px 10px; clear:both;}
-->
</style>

<form action="../admin/page/sliderProcess.php" method="post" enctype="multipart/form-data" name="addroom">
 Select Image: <br />
 <input type="file" name="image" class="ed">
 image size(1024x160)<br /><br />
 Title<br />
 <input name="title" type="text" class="ed" id="title" />
 <input type="submit" name="Submit" value="Upload" id="button1" />
</form>
<p><br />
Image slider</p>
<hr />
<center>
</center><br />
<table width="87%"  class="table table-striped table-bordered">
  <thead>
    <tr>
      <th width="7%">Image Slider</th>
      <th width="14%">Title</th>
      <th width="27%">Action</th>
    </tr>
  </thead>
  <tbody>
    <?php include('../connection.php');
							$result = mysql_query("SELECT * FROM imageslider ORDER BY id DESC");
while($row = mysql_fetch_array($result))
{
							$id=$row['id'];
							?>
    <tr id="row">
      <td><?php echo '<div id="imagelist">';
echo '<img  width="450" src="'.$row['image'].'">'; 
echo '</div>';?></td>
      <td><?php echo $row['namePicture']?></td>
      <td><a href="?page=UpdateSlider&id=<?php echo $row["id"];?>"  data-toggle="modal"  class="btn-success" >Edit </a> &nbsp;&nbsp;&nbsp;&nbsp;<a href="../Admin/page/deleteSlider_Process.php?id= <?php echo $row ['id']; ?>"  data-toggle="modal"  class="tooltip-inner" >Delete </a></td>
    </tr>
    <?php } ?>
  </tbody>
</table>
<br />
<br />
<hr />
<center></center>