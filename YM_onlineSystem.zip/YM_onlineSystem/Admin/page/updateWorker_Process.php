<?php
$connect = @mysql_connect('localhost','root','') or die(mysql_error()); 
mysql_select_db('data') or die(mysql_error());	
$getid=$_REQUEST['id'];

			if (!isset($_FILES['image']['tmp_name'])) {
	echo "";	
	}else{
	$file=$_FILES['image']['tmp_name'];
	
	$image_name= addslashes($_FILES['image']['name']);

	move_uploaded_file($_FILES["image"]["tmp_name"],"photos/" . $_FILES["image"]["name"]);
			$photo="../Admin/page/photos/".$_FILES["image"]["name"];
			$id=$_POST['id'];
			$staff_name=$_POST['staff_name'];
			$staff_ic=$_POST['staff_ic'];
            $staff_password=$_POST['staff_password'];
            $staff_username=$_POST['staff_username']; 		            
            $staff_gender=$_POST['staff_gender'];
            $staff_no=$_POST['staff_no'];
            $staff_address=$_POST['staff_address']; 		            
            $staff_email=$_POST['staff_email'];
			
           

			
			mysql_query("UPDATE staff SET staff_name='$staff_name',staff_ic='$staff_ic',loginPass='$staff_password',staff_username='$staff_username',staff_gender='$staff_gender',staff_no='$staff_no',staff_address='$staff_address',staff_email='$staff_email',location='$photo' WHERE staff_id='$id'");
		//	$result=mysql_query or die(mysql_error());
			echo "<script>
	  alert('Update succesfully');
	  window.location = '../homeAdmin.php?page=reviewWorker';
	  </script>";
           
	}
 
	
      
?>
