<?php	
$connect = @mysql_connect('localhost','root','') or die(mysql_error()); 
mysql_select_db('data') or die(mysql_error());	
$noplat=$_POST['platenumber'];
$date=$_POST['date'];
$note=$_POST['note'];


$query="INSERT INTO noted  (NOPlateMotor,date,note ) VALUES ('$noplat','$date','$note')";
			$result=mysql_query($query) or die(mysql_error());
 echo "<script>
	 window.history.back();
	  </script>";		
           
exit();	
 
	
      
?>
