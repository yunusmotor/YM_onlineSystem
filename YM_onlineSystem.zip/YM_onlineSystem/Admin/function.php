<?php
function admin_getPage($page){
	if ($page != ""){
		include("page/".$page.".php");
	}
	else{
		include("?page=review_admin");
	}
}
function admin_getPage1($page){
	if ($page != ""){
		include("page/".$page.".php");
	}
	else{
		include("?page=review_Worker");
	}
}

function admin_getPagedeposit() {
	include("../Admin/page/detailCustomer_deposit.php");
}
function admin_getPageDepositPayment() {
	
	include("../Admin/page/table.php");
}
function admin_getPagenoted() {
	include("../Admin/page/noted.php");
}


?>
