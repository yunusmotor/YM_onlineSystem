<?php


include("../session.php");
include_once("function.php");
include_once("../connection.php");



ini_set('display_errors',0);
if( isset( $_REQUEST['calculate'] ))
{
$add1 = $_REQUEST['fvalue'];
$add2 = 800;
$add3 = $_REQUEST['deposit'];
$res= $add1+$add2-$add3;
$percent=$_REQUEST['percent'];
if($percent=="10")
{
	$res1 = (10*$res)/100;
	}
if($percent=="15")
{
	$res1 = (15*$res)/100;
	}
if($percent=="20")
{
	$res1 = (20*$res)/100;
	}
if($percent=="25")
{
	$res1 = (25*$res)/100;
	}
if($percent=="30")
{
	$res1 = (30*$res)/100;
	}
if($percent=="35")
{
	$res1 = (35*$res)/100;
	}
if($percent=="40")
{
	$res1 = (40*$res)/100;
	}
}
$res2=$res+$res1;
$month=$_REQUEST['month'];
if($month=="12( 1 Year )")
{
$total= $res2/12;
}
if($month=="18( 1 1/2 Year )")
{
$total= $res2/18;
}
if($month=="24 ( 2 Year )")
{
$total= $res2/24;
}
if($month=="30 ( 2 1/2 Year )")
{
$total= $res2/30;
}
if($month=="36 ( 3 Year )")
{
$total= $res2/36;
}
if($month=="42 ( 3 1/2 Year )")
{
$total= $res2/42;
}
if($month=="48 ( 4 Year )")
{
$total= $res2/48;
}

?>
<!DOCTYPE HTML>
<html>
<head>
<title>YUNUS MOTOR ONLINE SYSTEM</title>
<link rel='shortcut icon' href='picture/logoym.png' />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Modern Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->

<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/lines.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<script src="js/jquery.min.js"></script>
<!----webfonts--->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'>
<!---//webfonts--->  
<!-- Nav CSS -->
<link href="css/custom.css" rel="stylesheet">
<style type="text/css">
#wrapper #page-wrapper .content_bottom .col-md-8.span_3 .bs-example1 .table {
	color: #000;
}
body,td,th {
	font-family: Roboto, sans-serif;
}
body {
	background-color: #000;
}
</style>
<!-- Metis Menu Plugin JavaScript -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<!-- Graph JavaScript -->
<script src="js/d3.v3.js"></script>
<script src="js/rickshaw.js"></script>
</head>
<body>
<div id="wrapper">
     <!-- Navigation -->
  <nav class="top1 navbar navbar-default navbar-static-top1" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
               
              <a class="navbar-brand" href="">Admin</a><br/>Date :<?php echo date('d m Y ');?>
            </div>
            <!-- /.navbar-header -->
            <ul class="nav navbar-nav navbar-right">
			  <li class="dropdown">
	        		<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-comments-o"></i><span class="badge"><?php
		
				$sql=mysql_query("select * from deposit INNER JOIN customer ON deposit.NOPlateMotor=customer.NOPlateMotor WHERE  no_Payment ");
				$comment_count=mysql_num_rows($sql);
				if($comment_count!=0)
				{
				echo '<span id="mes">'.$comment_count.'</span>';
				}
			?></span></a>
       		    <ul class="dropdown-menu">
					<li class="dropdown-menu-header">
							<strong>Tunggakan</strong>
							
					</li>
						
					<li class="avatar"><?php
$hari=date('d M Y');
$tunggakan=mktime(0, 0, 0, date("m")-3);
echo date("l, d-M-Y", $tunggakan);
if($hari <= $tunggakan){
	$paparan=$hari;
}
					
								
						$result1= mysql_query("select max(perMonth) from deposit " ) or die (mysql_error());
						$result= mysql_query("select * from deposit INNER JOIN customer ON deposit.NOPlateMotor=customer.NOPlateMotor where deposit.date <=  $tunggakan  " ) or die (mysql_error());
								while ($row= mysql_fetch_array ($result) ){
								$id=$row['NOPlateMotor'];
								?>
							<a href="homeAdmin.php?page=deposit_Bymonthly&id=<?php echo $row["NOPlateMotor"];?>">
								<img src="<?php echo $row['inFront_IC']; ?>" alt=""/>
					  <div> <?php echo $row ['NOPlateMotor']; ?> </div>
							<small><b><?php echo $row ['Name_Cust']; ?></b></small>
                            <small><?php echo $row ['ContactNO_Cust']; ?></small>
                            <small><?php echo $row ['perMonth']; ?></small>
							<span class="label label-info">NEW</span><?php } ?>
							
				  </li>
						
					<li class="dropdown-menu-footer text-center">
							<a href="#">View all messages</a>
					</li>	
       		    </ul>
	      		</li>
			    <li class="dropdown">
	        		<a href="#" class="dropdown-toggle avatar" data-toggle="dropdown"> <img src= "<?php
		  
 echo $results['location']; ?>" /></a>
	        		<ul class="dropdown-menu">
						<li class="dropdown-menu-header text-center">
							<strong>Account</strong>
						</li>
						<li class="m_2"><a href="#"><i class="fa fa-user"></i> Name :<span class="label label-info"><?php echo $results['staff_username'];?></span></a></li>
						<li class="m_2"><a href="#"><i class="fa fa-envelope-o"></i> Email <span class="label label-primary">
						<?php echo $results['staff_email'];?></span></a></li>
						<li class="dropdown-menu-header text-center">
							<strong>Settings</strong>
						</li>
						
						
						<li class="divider"></li>
						<li class="m_2"><a href="../homepage/logout_process.php"><i class="fa fa-lock"></i> Logout</a></li>	
	        		</ul>
	      		</li>
	</ul>
          <div>
		  <div class="navbar-default sidebar" role="navigation">
              
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="homeAdmin.php?page=review_admin"><i class="fa-sitemap fa-fw nav_icon"></i>REVIEW ADMIN</a>
                        </li><li>
                            <a href="homeAdmin.php?page=reviewWorker"><i class="fa-sitemap fa-fw nav_icon"></i>REVIEW WORKER</a>
                        </li>
                        
                        <li>
                            <a href=""><i class="fa fa-indent nav_icon"></i>INFORMATION CUSTOMER<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="homeAdmin.php?page=InputPlateNo">INPUT PLATE NO.</a>
                                </li>
                                <li>
                                    <a href="homeAdmin.php?page=reviewAll_Cust">REVIEW INFORMATION CUSTOMER</a>
                                </li>
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        
                            
                        <li>
                            <a href=""><i class="fa fa-table nav_icon"></i>ADD CUSTOMER<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="homePage.php?page=deposit">DEPOSIT</a>
                                </li>
                             
                                <li>
                                    <a href="homeAdmin.php?page=fullLoan">FULL LOAN</a>
                                </li>
                            </ul>
        
                        </li>
                         <li>
                            <a href=""><i class="fa fa-check-square-o nav_icon"></i>PRODUCT INFORMATION<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="homeAdmin.php?page=addProduct">ADD PRODUCT</a>
                                </li>
                                <li>
                                    <a href="homeAdmin?page=homeAlbum"> REVIEW PRODUCT</a>
                                </li>
                                <li>
                                    <a href="UpdateProduct.php">UPDATE PRODUCT</a>
                                </li>
                                <li>
                                    <a href="ReviewProduct.php">REVIEW PRODUCT</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href=""><i class="fa fa-flask nav_icon"></i>DELETE INFORMATION<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="DeleteCustomerInformation.php">DELETE CUSTOMER INFORMATION</a>
                                </li>
                                <li>
                                    <a href="DeleteWorkerInformation.php">DELETE WORKER INFORMATION</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href=""><i class="fa fa fa-envelope nav_icon"></i>REPORT<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="ReportinfoProduct.php">REPORT INFORMATION PRODUCT</a>
                                </li>
                                <li>
                                    <a href="ReportinfoCust.php">REPORT INFORMATION CUSTOMER</a>
                                </li>
                                <li>
                                    <a href="ReportInfoWorker.php">REPORT INFORMATION WORKER</a>
                                </li>
                                <li>
                                    <a href="PrintReport.php">PRINT REPORT</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
</div>
            <!-- /.navbar-static-side -->
  </nav>
  <div id="page-wrapper">
        <div class="graphs">
     	<div class="col_3">
     	  <div class="clearfix"> </div>
      </div>
       <div class="bs-example5" data-example-id="default-media">
        <div class="clearfix">   
          <p>
            <center>
            <div id="wrapper">
          </p>
          <form action="" >
          <div id="header">
              <table width="944" border="0">
                <tr>
                  <td width="118" bgcolor="#999999"><img src="symbol calculator.png" alt="" width="113" height="102" class="img"  /></td>
                  <td width="816" bgcolor="#999999"><strong>CALCULATOR LOAN FOR MONTH</strong></td>
                </tr>
              </table>
            </div>
            <div id="body">
              <table width="924" style="border:groove #00FF99">
                <tr>
                  <td width="205" bgcolor="#CCCCCC" font-family:'Times New Roman'">Price Cash</td>
                  <td width="326" colspan="1"><input name="fvalue" type="text" style="color:red"/></td>
                  <td width="371"></td>
                <tr>
                  <td height="34" bgcolor="#CCCCCC" font-family:'Times New Roman'">Service Change</td>
                  <td><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;+ RM800</p></td>
                  <td width="371"></td>
                <tr>
                  <td bgcolor="#CCCCCC"  font-family:'Times New Roman'">Deposit &nbsp;<span class="auto-style5">(-)</span></td>
                  <td class="auto-style5"><input name="deposit" type="text"  style="color:red"/></td>
                  <td width="371">&nbsp;&nbsp;&nbsp;&nbsp; 10 % = 1 &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;YEAR (12 MONTH)</td>
                <tr>
                  <td bgcolor="#CCCCCC"  font-family:'Times New Roman'">Percentage</td>
                  <td class="auto-style5">(X)
                    <select name="percent" id="percent">
                      <option>10</option>
                      <option>15</option>
                      <option>20</option>
                      <option>25</option>
                      <option>30</option>
                      <option>35</option>
                      <option>40</option>
                    </select>
                    %</td>
                  <td width="371">&nbsp;&nbsp;&nbsp;&nbsp;
                    15% = 1 1/2&nbsp; YEAR (18 MONTH)                  
                </tr>
                <tr bgcolor="#CCCCCC"></tr>
                <tr>
                  <td bgcolor="#CCCCCC" ">Month</td>
                  <td style="color:darkblue">( / )
                    <select name="month" id="month">
                      <option>12( 1 Year )</option>
                      <option>18( 1 1/2 Year )</option>
                      <option>24 ( 2 Year )</option>
                      <option>30 ( 2 1/2 Year )</option>
                      <option>36 ( 3 Year )</option>
                      <option>42 ( 3 1/2 Year )</option>
                      <option>48 ( 4 Year )</option>
                    </select></td>
                  <td width="371">&nbsp;&nbsp;&nbsp;&nbsp;
                    20% = 2&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;YEAR (24 MONTH)                  
                </tr>
                <tr bgcolor="#CCCCCC"></tr>
                <tr>
                  <td bgcolor="#CCCCCC" >&nbsp;</td>
                  <td style="color:darkblue">&nbsp;</td>
                  <td width="371">&nbsp;&nbsp;&nbsp;&nbsp;
                    25% = 2 1/2&nbsp; YEAR (30 MONTH)                  
                </tr>
                <tr bgcolor="#CCCCCC"></tr>
                <tr>
                  <td bgcolor="#CCCCCC" >&nbsp;</td>
                  <td style="color:darkblue"><input type="submit" name="calculate" value="Calculate" style="color:wheat;background-color:rosybrown" /></td>
                  <td width="371">&nbsp;&nbsp;&nbsp;&nbsp;
                    30% = 3&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;YEAR (36 MONTH)                  
                </tr>
                <tr bgcolor="#CCCCCC"></tr>
                <tr>
                  <td bgcolor="#CCCCCC" >Total Payment per Month</td>
                  <td bgcolor="#999999" style="color:darkblue" name="total"><b>
                    <?php 
          echo  $total
				
?></b></td>
                  <td width="371">                  
                </tr>
                  </tr>
                
                <tr>
                  <td bgcolor="#CCCCCC"></td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td bgcolor="#CCCCCC" >&nbsp;</td>
                  <td >&nbsp;</td>
                  <td width="371">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="homeAdmin.php?page=RegisterCustomer&permonthly=<?php echo  $total ?>&cash=<?php echo $add1 ?>&deposit=<?php echo $add3 ?>&month=<?php echo $month?>" class="btn btn-info">Add</a>
                &nbsp;    <input type="reset" name="reset"  style="color: wheat; background-color: #F30" id="add2"  class="btn btn-info"/>
                </tr>
                  </tr>
                
                  </tr>
                
              </table>
            </div>
            <div id="footer" >
              <table width="937" border="0">
                <tr>
                  <td width="931" bgcolor="#999999">&nbsp;</td>
                </tr>
              </table>
            </div>
          </form>
          <p>&nbsp; </p>
        </div>
	  </div>
	  <div class="span_11">
	    <div class="clearfix"> </div>
    </div>
     <div class="clearfix"> </div>
    </div>
    <div class="content_bottom">
      <div class="clearfix"> </div>
    </div>
		<div class="copy">
            <p>Copyright &copy; 2017 YUNUS MOTOR ONLINE SYSTEM. All Rights Reserved | Design by Student Politechnic</p>
	    </div>
  </div>
       </div>
      <p><!-- /#page-wrapper --></p>
     <script src="js/bootstrap.min.js"></script>
</body>
</html>
