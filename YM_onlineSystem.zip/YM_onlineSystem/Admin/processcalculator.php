<?php
ini_set('display_errors',0);
if( isset( $_REQUEST['calculate'] ))
{
$add1 = $_REQUEST['fvalue'];
$add2 = 800;
$add3 = $_REQUEST['deposit'];
$res= $add1+$add2-$add3;
$percent=$_REQUEST['percent'];
if($percent=="10")
{
	$res1 = (10*$res)/100;
	}
if($percent=="15")
{
	$res1 = (15*$res)/100;
	}
if($percent=="20")
{
	$res1 = (20*$res)/100;
	}
if($percent=="25")
{
	$res1 = (25*$res)/100;
	}
if($percent=="30")
{
	$res1 = (30*$res)/100;
	}
if($percent=="35")
{
	$res1 = (35*$res)/100;
	}
if($percent=="40")
{
	$res1 = (40*$res)/100;
	}
}
$res2=$res+$res1;
$month=$_REQUEST['month'];
if($month=="12( 1 Year )")
{
$total= $res2/12;
}
if($month=="18( 1 1/2 Year )")
{
$total= $res2/18;
}
if($month=="24 ( 2 Year )")
{
$total= $res2/24;
}
if($month=="30 ( 2 1/2 Year )")
{
$total= $res2/30;
}
if($month=="36 ( 3 Year ))")
{
$total= $res2/36;
}
if($month=="42 ( 3 1/2 Year )")
{
$total= $res2/42;
}
if($month=="48 ( 4 Year )")
{
$total= $res2/48;
}
?>