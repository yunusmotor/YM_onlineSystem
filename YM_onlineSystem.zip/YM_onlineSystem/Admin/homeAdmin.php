<?php

include("../session.php");
include_once("function.php");
include_once("../connection.php");

?>

<!DOCTYPE HTML>
<html>
<head>
<title>YUNUS MOTOR ONLINE SYSTEM</title>
<link rel='shortcut icon' href='picture/logoym.png' />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Modern Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->

<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/lines.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<script src="js/jquery.min.js"></script>
<!----webfonts--->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'>
<!---//webfonts--->  
<!-- Nav CSS -->
<link href="css/custom.css" rel="stylesheet">
<style type="text/css">
#wrapper #page-wrapper .content_bottom .col-md-8.span_3 .bs-example1 .table {
	color: #000;
}
body,td,th {
	font-family: Roboto, sans-serif;
}
body {
	background-color: #000;
}
</style>
<!-- Metis Menu Plugin JavaScript -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<!-- Graph JavaScript -->
<script src="js/d3.v3.js"></script>
<script src="js/rickshaw.js"></script>
</head>
<body>
<div id="wrapper">
     <!-- Navigation -->
  <nav class="top1 navbar navbar-default navbar-static-top1" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
               
              <a class="navbar-brand" href="?page=review_admin">Admin</a><center>Date :<?php echo date('d m Y ');?></center>
            </div>
            <!-- /.navbar-header -->
            <ul class="nav navbar-nav navbar-right">
				
			    <li class="dropdown">
	        		<a href="#" class="dropdown-toggle avatar" data-toggle="dropdown"> <img src= "<?php
		  
 echo $results['location']; ?>" /></a>
	        		<ul class="dropdown-menu">
						<li class="dropdown-menu-header text-center">
							<strong>Account</strong>
						</li>
						<li class="m_2"><a href="#"><i class="fa fa-user"></i> Name :<span class="label label-info"><?php echo $results['staff_username'];?></span></a></li>
						<li class="m_2"><a href="#"><i class="fa fa-envelope-o"></i> Email <span class="label label-primary">
						<?php echo $results['staff_email'];?></span></a></li>
						<li class="dropdown-menu-header text-center">
							<strong>Settings</strong>
						</li>
						
						
						<li class="divider"></li>
						<li class="m_2"><a href="../homepage/logout_process.php"><i class="fa fa-lock"></i> Logout</a></li>	
	        		</ul>
	      		</li>
	</ul>
          <div>
		  <div class="navbar-default sidebar" role="navigation">
              
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="?page=review_admin"><i class="fa-sitemap fa-fw nav_icon"></i>REVIEW ADMIN</a>
                        </li><li>
                            <a href="?page=reviewWorker"><i class="fa-sitemap fa-fw nav_icon"></i>REVIEW WORKER</a>
                        </li>
                        
                        <li>
                            <a href=""><i class="fa fa-indent nav_icon"></i>INFORMATION CUSTOMER<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="?page=InputPlateNo">ENTER PLATE NO.</a>
                                </li>
                                <li>
                                    <a href="?page=reviewAll_Cust">REVIEW INFORMATION CUSTOMER</a>
                                </li>
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        
                            
                        <li>
                            <a href=""><i class="fa fa-table nav_icon"></i>PAYMENT<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="?page=deposit">DEPOSIT</a>
                                </li>
                             
                                <li>
                                    <a href="?page=fullLoan">FULL LOAN</a>
                                </li>
                            </ul>
        
                        </li>
                         <li>
                            <a href=""><i class="fa fa-check-square-o nav_icon"></i>PRODUCT INFORMATION<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="?page=addProduct">ADD PRODUCT</a>
                                </li>
                                <li>
                                    <a href="?page=homeAlbum"> REVIEW PRODUCT</a>
                                </li> <li>
                                    <a href="?page=addSlider"> ADD SLIDER</a>
                                </li>
                                
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        
                        <li>
                            <a href=""><i class="fa fa fa-envelope nav_icon"></i>REPORT<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="?page=reportInformationProduct">REPORT INFORMATION PRODUCT</a>
                                </li>
                                <li>
                                    <a href="?page=reportInformationCustomer">REPORT INFORMATION CUSTOMER</a>
                                </li>
                                <li>
                                    <a href="?page=reportInformationWorker">REPORT INFORMATION WORKER</a>
                                </li>
                                
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
</div>
            <!-- /.navbar-static-side -->
  </nav>
  <div id="page-wrapper">
        <div class="graphs">
     	<div class="col_3">
     	  <div class="clearfix"> </div>
      </div>
       <div class="bs-example5" data-example-id="default-media">
        <div class="clearfix">   <?php admin_getPage($_REQUEST['page']); ?></div>
	  </div>
	  <div class="span_11">
	    <div class="clearfix"> </div>
    </div>
     <div class="clearfix"> </div>
    </div>
    <div class="content_bottom">
      <div class="clearfix"> </div>
    </div>
		<div class="copy">
            <p>Copyright &copy; 2017 YUNUS MOTOR ONLINE SYSTEM. All Rights Reserved | Design by Student Politechnic</p>
	    </div>
  </div>
       </div>
      <p><!-- /#page-wrapper --></p>
     <script src="js/bootstrap.min.js"></script>
</body>
</html>
