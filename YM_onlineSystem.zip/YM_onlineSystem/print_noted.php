<?php
session_start();
include_once("connection.php");
 

$getid=$_REQUEST["id"];
$result=mysql_query("SELECT * FROM noted INNER JOIN customer ON noted.NOPlateMotor=customer.NOPlateMotor where no_payment ='$getid'");
$row=mysql_fetch_array($result);

?>
<?php
if(!isset($_SESSION['staff_username'])){
    
	die();
}

	   $sql = "SELECT * FROM staff WHERE staff_username='".$_SESSION['staff_username']."'";
        
        $query = mysql_query($sql)
                    or die(mysql_error());
                    
        $results = mysql_fetch_array($query);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.font {
	font-size: 10px;
}
.font {
	font-size: 9px;
}
.font {
	font-weight: bold;
}
.font p {
	font-weight: bold;
	font-size: x-small;
	text-align: center;
}
.font {
	font-weight: bold;
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	font-size: 14px;
}
.font1 {
	font-weight: bold;
}
.font1 {
	font-weight: bold;
}
.fontcenter {
	text-align: center;
	font-weight: bold;
	font-family: Verdana, Geneva, sans-serif;
	font-size: 24px;
}
.font10 {
	font-size: 16px;
	font-weight: bold;
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
}
.font14 {
	font-size: 16px;
}
.b {
	font-weight: bold;
}
.font9 {
	font-size: 16px;
}
.font12 .font {
	font-size: 12px;
}
.font14 .font {
	font-size: 14px;
}
.font12 .font {
	font-size: 12px;
}
.FONT16 {
	font-size: 14px;
}
.b {
	font-weight: bold;
}
f18 {
	font-size: 18px;
}
#form1 table tr td table tr td table tr td {
	font-size: medium;
	font-weight: bold;
	font-family: "Times New Roman", Times, serif;
}
#form1 p {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: 16px;
}
.f14 {
	font-size: 16px;
	font-family: "Arial Black", Gadget, sans-serif;
}
f20 {
	font-size: 18px;
}
#form1 p span {
	font-size: 18px;
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
}
b1 {
	color: #000;
}
#form1 table tr td {
	color: #000;
	text-align: center;
}
</style>
</head>

<body><center>

  <form id="form1" name="form1" method="post" action="">
    <p><img src="picture/logoym.png" alt="" width="59" height="70" /><img src="picture/Yamaha-logo.png" width="38" height="44" alt="logoyamaha" /><img src="picture/Sym-logo.png" width="40" height="48" alt="logosym" /><img src="picture/Honda-logo.png" width="49" height="53" alt="logohonda" /><img src="picture/Modenas-logo.png" width="50" height="51" alt="logomodenas" /><img src="picture/Demak-logo.png" width="28" height="44" alt="logoyamaha" />
    <br />
    <span class="f14">YUNUS MOTOR ONLINE SYSTEM</span><br />
   LOT  1162,GR.FLOOR,JLN DATUK PENGAIRAN HIPNI     
    <br />96200 DARO,SARAWAK <br />TEL&nbsp;: <span class="font1">0198894904</span> (HP)/<span class="font1">084-823835</span>(FAX)     
    <p><span class="font">&nbsp;DATE&nbsp; : <span style="text-align:center; word-break:break-all; width:100px;"><?php echo date('d M Y'); ?></span></span><span class="font">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="font">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="font">&nbsp;</span><span class="font">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>    
    
   
    <span class="font">&nbsp;</span><span class="font">&nbsp;&nbsp;&nbsp;</span><p><span class="">Plate No. :<span style="text-align:center; word-break:break-all; width:100px;"><?php echo $row ['NOPlateMotor']; ?></span></span>   <br />
     <span class="font"> Name&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : <span style="text-align:center; word-break:break-all; width:100px;"><?php echo $row ['Name_Cust']; ?></span></span>     
    <p><span class="">Description<span class="font">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="font">&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="font">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="font">&nbsp;&nbsp;&nbsp;</span>Amount(RM)</span><br />
      <span class="font14">.......................................................................</span><br />    
      <span class="b"><span style="text-align:center; word-break:break-all; width:100px;">
      <textarea name="comment" cols="40" rows="10" disabled="disabled" class="f14" readonly ><?php echo $row ['note']; ?></textarea>
      </span>&nbsp;&nbsp;&nbsp;&nbsp;</span>    
    <p><span class="font14">.......................................................................</span>
    <br />
    <p><br />   
    <p><span class="font10"><span class="font">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span class="font10"><span class="font">&nbsp;</span></span><span class="font10"><span class="font">&nbsp;&nbsp;</span><span class="font">&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span class="font10"><span class="font">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="font">&nbsp;&nbsp;</span><span class="font">&nbsp;&nbsp;</span></span><span class="font10"><span class="font">&nbsp;</span></span><span class="font10"><span class="font">&nbsp;&nbsp;</span><span class="font">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="font">&nbsp;&nbsp;</span><span class="font">&nbsp;&nbsp;</span></span><span class="font10"><span class="font">&nbsp;</span></span><span class="font10"><span class="font">&nbsp;&nbsp;</span><span class="font">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span>    
   <br />
   (<span style="text-align:center; word-break:break-all; width:100px;"> <?php echo $results['staff_name']; ?></span> )<span class="font10"><span class="font">&nbsp;</span></span><span class="font10"><span class="font">&nbsp;&nbsp;&nbsp;</span></span>    
    <p><span class="FONT16">***** Thank You *****<br />
Please Come Again</span>    
    <table width="630" border="0">
      <tr>
        <td width="21" height="27" bgcolor="#000">&nbsp;</td>
        <td width="14">&nbsp;</td>
        <td width="22" bgcolor="#000">&nbsp;</td>
        <td width="20">P</td>
        <td width="24" bgcolor="#000">&nbsp;</td>
        <td width="21">A</td>
        <td width="24" bgcolor="#000">&nbsp;</td>
        <td width="18">I</td>
        <td width="20" bgcolor="#000">&nbsp;</td>
        <td width="9">D</td>
        <td width="24" bgcolor="#000">&nbsp;</td>
        <td width="10">&nbsp;</td>
        <td width="21" bgcolor="#000">&nbsp;</td>
        <td width="8">&nbsp;</td>
        <td width="35" bgcolor="#000">&nbsp;</td>
        <td width="16">&nbsp;</td>
        <td width="36" bgcolor="#000">&nbsp;</td>
        <td width="23">&nbsp;</td>
        <td width="29" bgcolor="#000">&nbsp;</td>
        <td width="158"><input type="submit" name="button" id="button" value="Print" onclick="print()" /></td>
      </tr>
    </table>
    <p>    
    
    <p><br />   
  </form>
  <table width="439" border="0">
      <tr>
        
        <td width="398">&nbsp;</td>
      </tr>
    </table></center>
</center>
</body>
</html>
