<?php
function ym_getMenu() {
	include("tabmenu/menu.php");
}

function ym_getPage($page){
	if ($page != ""){
		include("homepage/".$page.".php");
	}
	else{
		include("homepage/page.php");
	}
}
function admin_getPagedeposit() {
	include("homepage/detailCustomer_deposit.php");
}
function admin_getPageDepositPayment() {
	
	include("homepage/table.php");
}







