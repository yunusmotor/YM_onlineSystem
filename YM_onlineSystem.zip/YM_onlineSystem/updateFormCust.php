<?php
include "connection.php";
include "session.php";
//$query= "SELECT * FROM customer WHERE Name_Cust='$username'";
//$result=mysql_query($query);
//$row=mysql_fetch_array($result);
?>
<html>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />  
	<meta name="keywords" content="Slider, Hi Slider, Simple HTML5 Slideshow, Free js slider" />
    <meta name="description" content="Slider created with Hi Slider which enable you to publish responsive jQuery image slideshows, seamless WordPress slider plugins, amazing website sliding banners and fancy JavaScript slideshow presentation" />    
<title>YUNUS MOTOR ONLINE SYSTEM</title>
<link rel='shortcut icon' href='picture/logoym.png' />
<head>
<style type="text/css">
body {
	background-image: url(picture/website-background-pattern.jpg);
}
</style>

  <script type="text/javascript" src="sliderengine/jquery.js"></script><script type="text/javascript" src="sliderengine/jquery.hislider.js"></script>
  
  <style>
  	html,body{height:100%; margin:0px;}	
  </style> 

<body onLoad="window.setTimeout('jam();',500)">
<center>
<div class="layout">
	<div class="bar">
	  <form method="get" action=""><table width="1042" border="0">
  		    <tr>
  		      <td width="228" height="155"><table width="226" height="185" border="0">
  		        <tr>
  		          <td width="49" height="150"><table width="49" height="203" border="0">
  		            <tr>
  		              <td height="21" bgcolor="#34495E">&nbsp;</td>
		              </tr>
  		            <tr>
  		              <td height="116" bgcolor="#CC3300">&nbsp;</td>
		              </tr>
  		            <tr>
  		              <td height="58" bgcolor="#34495E">&nbsp;</td>
		              </tr>
	              </table></td>
  		          <td width="189" bgcolor="#CC3300"><img src="picture/logoym.png" width="169" height="139" alt="logo"></td>
	            </tr>
	          </table></td>
                 <td width="794" bgcolor="#34495E"><table width="838" height="162" border="0">
                   <tr>
                     <td width="778"><table width="823" border="0">
                       <tr><td width="496" height="26" bgcolor="#34495E"> <img src="picture/jam/0.gif" alt="" /><img src="picture/jam/0.gif" alt="" /><img src="picture/jam/titk_bertindih.gif" alt="" /><img src="picture/jam/0.gif" alt="" /><img src="picture/jam/0.gif" alt="" /><img src="picture/jam/titk_bertindih.gif" alt="" /><img src="picture/jam/0.gif" alt="" /><img src="picture/jam/0.gif" alt="" /></td>
                         <td width="103" bgcolor="#34495E"><span class="cariMotor">Cari Motor : </span></td>
                         <td width="167" bgcolor="#34495E"><input name="page" type="hidden" value="view_motor" />
                           <input name="txtCari" type="text" id="txtCari" />
                           <label for="textfield"></label></td>
                         <td width="39" bgcolor="#CC3300"><input type="submit" name="btnCari" id="btnCari" value="Cari" /></td>
                       </tr>
                     </table></td>
                   </tr>
                   <tr>
                     <td height="79" bgcolor="#34495E"><img src="picture/namecompany.png" width="632" height="44" alt="namecompany">
                       <table width="200" border="0">
                         <tr>
                           <td height="36"><img src="picture/Yamaha-logo.png" width="90" height="34" alt="logoyamaha"></td>
                           <td><img src="picture/Honda-logo.png" width="90" height="34" alt="logohonda"></td>
                           <td><img src="picture/Sym-logo.png" width="90" height="34" alt="logosym"></td>
                           <td><img src="picture/Modenas-logo.png" width="90" height="34" alt="logomodenas"></td>
                           <td><img src="picture/Yamaha-logo.png" width="90" height="34" alt="logoyamaha"></td>
                         </tr>
                        
                     </table>
                     </td>
                   </tr>
                    
                     <td height="21" bgcolor="#34495E">&nbsp;<!-- <?php ym_getMenu(); ?> --></td>
</tr>

                 
              </table></td>
      
  		     
  		      
            
            
	      </table>
	  </form>
	  <table width="1066" border="0">
	    <tr>
	      <td width="254" height="337">&nbsp;</td>
	      <td width="802"><form name="form1" method="post" action="updateProcessFormCust.php">
	        <table width="554" border="0" align="center">
	          <tr>
	            <td width="162" bgcolor="#CC9900">Name</td>
	            <td width="379"><label>
	              <input name="Name_Cust" type="text" id="Name_Cust" size="50" value="<?php echo "$row[Name_Cust]" ?>">
	              </label></td>
	            </tr>
	          <tr>
	            <td bgcolor="#CC9900">Ic Number</td>
	            <td><label>
	              <input name="ICNumber_Cust" type="text" id="ICNumber_Cust" size="30" value="<?php echo "$row[ICNumber_Cust]" ?>">
	              </label></td>
	            </tr>
	          <tr>
	            <td bgcolor="#CC9900">Contact Number</td>
	            <td><label>
	              <input type="text" name="ContactNo_Cust" id="ContactNo_Cust" value="<?php echo "$row[ContactNo_Cust]" ?>">
	              </label></td>
	            </tr>
	          <tr>
	            <td bgcolor="#CC9900">No. Plate Number</td>
	            <td><label>
	              <input name="NOPlateMotor" type="text" id="NOPlateMotor" size="30" value="<?php echo "$row[NOPlateMotor]" ?>">
	              </label></td>
	            </tr>
	          <tr>
	            <td bgcolor="#CC9900">No. Engine Motor</td>
	            <td><label>
	              <input name="No_EngineMotor" type="text" id="No_EngineMotor" size="30" value="<?php echo "$row[No_EngineMotor]" ?>">
	              </label></td>
	            </tr>
	          <tr>
	            <td bgcolor="#CC9900">Type Motor</td>
	            <td><label>
	              <input type="text" name="TypeMotor" id="TypeMotor" value="<?php echo "$row[TypeMotor]" ?>">
	              </label></td>
	            </tr>
	          <tr>
	            <td bgcolor="#CC9900">Color Motor</td>
	            <td><label>
	              <input type="text" name="ColorMotor" id="ColorMotor" value="<?php echo "$row[ColorMotor]" ?>">
	              </label></td>
	            </tr>
	          <tr>
	            <td bgcolor="#CC9900">Monthly Payment</td>
	            <td><label>
	              <input type="text" name="Monthly_Payment" id="Monthly_Payment" value="<?php echo "$row[Monthly_Payment]" ?>">
	              </label></td>
	            </tr>
	          <tr>
	            <td bgcolor="#CC9900">Payment Balance</td>
	            <td><label>
	              <input type="text" name="PaymentBalance" id="PaymentBalance" value="<?php echo "$row[PaymentBalance]" ?>">
	              </label></td>
	            </tr>
	          <tr>
	            <td bgcolor="#CC9900">Product Supplier Name</td>
	            <td><label>
	              <input name="ProductSuplierName" type="text" id="ProductSuplierName" size="30" value="<?php echo "$row[ProductSuplierName]" ?>">
	              </label></td>
	            </tr>
	          <tr>
	            <td>&nbsp;</td>
	            <td><input type="submit" name="Update" id="Update" value="Update">
	              <input type="reset" name="Clear" id="Clear" value="Clear"></td>
	            </tr>
	          </table>
          </form></td>
        </tr>
	    <tr>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
        </tr>
      </table>
	</div>
		<div class="header">
       	<!-- <h1 align="center">Kelfin Eka Motor</h1> -->
        
    </div>
    <div class="navigasi">
    
</div>
        
<div class="footer">
        <h3>&copy;copyright 2016 student polytechnic</h3>
    </div>
        
  </div>
</center>
</body>
</html>
