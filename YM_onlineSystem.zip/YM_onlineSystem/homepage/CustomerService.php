<?php

include_once("connection.php");
include_once("function.php");
     
$query = mysql_query("select * from customer");
?>

<!DOCTYPE HTML>
<html>
<head>
<title>YUNUS MOTOR ONLINE SYSTEM</title>
<link rel='shortcut icon' href='picture/logoym.png' />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
#wrapper #page-wrapper .content_bottom .col-md-8.span_3 .bs-example1 .table {
	color: #000;
}
body,td,th {
	font-family: Roboto, sans-serif;
}
body {
	background-color: #FFF;
}
.style15 {font-size: 24px}
.style2 {
	color: #FF3300;
	font-size: 18px;
}
.style5 {font-size: 36px;
	font-family: Georgia, "Times New Roman", Times, serif;
}
.style21 {
	color: #000000
}
#ap_table_login tbody tr td {
	color: #F30;
	font-size: 18px;
	text-align: center;
}
hr{height:0; border:none; border-bottom:1px solid rgba(255,255,255,0.13); border-top:1px solid rgba(0,0,0,1); margin:9px 10px; clear:both;}
.f {
	font-size: 20px;
}
</style>

</head>
<body>
<hr><form action="?page=searchCustProcess"  method="post" ><center>
  <table  align="center">
    <tr style="height:190px; width:1020px">
     
      <td width="368" height="327"align="center"  style=" width:255px; border:0px solid #0000CC;bgcolor:#CCCCCC;" ><div style="height:300px; width:830px; float:left;border:3px solid #B9B9B9;border-radius:10px; margin-left:12px; margin-top:20px;"><br/><br/><br/><br/>
          <table width="200" border="0">
            <tr>
              <td><table width="449" border="0">
                <tr>
                  <td width="136">Search By No. Plate</td>
                  <td width="92">&nbsp;</td>
                  <td width="207"><label>
                    <input name="PlatField" style="border:3px solid #F30;"  type="text" id="PlatField" >
                  </label></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>Registered IC. No</td>
                  <td>&nbsp;</td>
                  <td><input name="ICField" type="text" style="border:3px solid #F30;" id="ICField"></td>
                </tr>
                <tr>
                  <td height="78">&nbsp;</td>
                  <td><input type="reset" name="button2" id="button2" value="Clear" style="height:25px; width:75px; background-color:#CC0; border:0px solid #333333; border-radius:5px; color:#FFFFFF;"></td>
                  <td><input type="submit" name="button" value="Search" style="height:25px; width:75px; background-color:#F30; border:0px solid #333333; border-radius:5px; color:#FFFFFF;"></td>
                </tr>
              </table></td>
              <td><img src="picture/photofilters_icon.png" alt="" width="195" height="163"></td>
            </tr>
          </table>
          <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
      </div></td>
   
    </tr>
  

  </table>
  <p>&nbsp;</p>
</center>
     </div>
   </div>
   <!-- /#page-wrapper -->
   </div>
   <hr>
   <p>&nbsp;</p><p>&nbsp;</p>
</form>
  
</body>
</html>






















