<?php
include "../connection.php";
session_start();
session_unset();
	 echo "<script>
	  alert('You successfully logout from the system');
	  window.location = '../index.php?page=page';
	  </script>
	  ";
    session_destroy();
	ob_end_flush();
	include '../index.php?page=page';
exit();
?>


