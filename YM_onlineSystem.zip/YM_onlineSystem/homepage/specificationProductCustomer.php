<?php

include("connection.php");
 

$getid=$_REQUEST["id"];
$result=mysql_query("SELECT * FROM product WHERE id ='$getid'");
$row=mysql_fetch_array($result);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.black {
	color: #000;
}
hr{height:0; border:none; border-bottom:1px solid rgba(255,255,255,0.13); border-top:1px solid rgba(0,0,0,1); margin:9px 10px; clear:both;}
.f36 {
	font-size: 36px;
	text-align: left;
	color: #F60;
}
.t {
	color: #AC6B0B;
	font-size: 36px;
}
.g {
	color: #000;
	font-size: 36px;
	text-align: left;
}
</style>
</head>

<body>
<hr />
<p class="t"  >Customer Service</p>
<form action="?page=searchCustProcess"  method="post" >
  <center>
    <table  align="center">
      <tr style="height:190px; width:1020px">
        <td width="368" height="327"align="center"  style=" width:255px; border:0px solid #0000CC;bgcolor:#CCCCCC;" ><div style="height:600px; width:830px; float:left;border:3px solid #B9B9B9;border-radius:10px; margin-left:12px; margin-top:20px;">
          <p><br/>
            <br/>
          <span class="g">Brand:</span>  <span class="f36"> &nbsp;&nbsp;&nbsp;&nbsp;<?php echo $row['brand']; ?><span style="text-align: left"></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="g">Price:</span> <?php echo ''.$row['price'].' '; ?></span></p>
          <p><br/>
            <span class="g">Model:</span> <span class="f36"><?php echo $row['title']; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><br/>
          </p>
          <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
          <table width="305" border="0">
            <tr>
              <td width="70">&nbsp;</td>
              <td width="225">&nbsp;</td>
            </tr>
            <tr>
              <td><?php echo '<p><img src="homepage../'.$row['image'].'"></p>'; ?></td>
              <td><p>Colors Available: <br/>
                <?php echo '<img src="homepage../'.$row['color1'].'">'; ?><?php echo '<img src="homepage../'.$row['color2'].'">'; ?><?php echo '<img src="homepage../'.$row['color3'].'">'; ?></p></td>
            </tr>
            <tr>
              <td  bgcolor=""><p>Overview:</p>
                <?php echo ''.$row['Overview'].' '; ?></td>
              <td>&nbsp;</td>
            </tr>
          </table>
          <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
        </div></td>
      </tr>
    </table>
    <p>&nbsp;</p>
  </center>
  </div>
  </div>
  <!-- /#page-wrapper -->
  </div>
  <hr />
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
<p>&nbsp;</p>
</body>
</html>
