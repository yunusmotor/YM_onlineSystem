<?php
include("connection.php");

// username and password sent from form
$username=$_POST['username'];
$password=$_POST['password'];

$username = stripslashes($username);
$password = stripslashes($password);
$username = mysql_real_escape_string($username);
$password = mysql_real_escape_string($password);

$sql="SELECT * FROM staff WHERE staff_username='$username' AND loginPass='$password'";
$result=mysql_query($sql);

// Mysql_num_row is counting table row
$count=mysql_num_rows($result);

if($count==1){
   if ($count['level']==1) {
        $_SESSION['staff_id'] = $username;
        echo "<script>
	  alert('Login sussesful');
	  window.location = '../Admin/homeAdmin.php?page=review_admin';
	  </script>
	  ";
        }
   else if ($count['level']==2) {
	   
        $_SESSION['staff_id'] = $username;
        echo "<script>
	  alert('Login sussesful');
	  window.location = '../Worker/index.html';
	  </script>
	  ";
   }
}
else {
echo "<script>
	  alert('Login Failed!!!');
	  window.location = '../homepage/loginForm.html';
	  </script>
	  ";
}
?>