<!DOCTYPE html>
<html>
<head>
	<title></title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />  
  
  
  <script src="sliderengine/jquery.js"></script>
        <script src="sliderengine/amazingslider.js"></script>
        <script src="sliderengine/initslider-1.js"></script>
<style type="text/css">
body {
	background-color: #999;
	color: #999;
}
hr{height:0; border:none; border-bottom:1px solid rgba(255,255,255,0.13); border-top:1px solid rgba(0,0,0,1); margin:9px 10px; clear:both;}
</style>

<script>
$(document).ready(function(){

$('[rel=tooltip]').bind('mouseover', function(){
	  
		
	
 if ($(this).hasClass('ajax')) {
	var ajax = $(this).attr('ajax');	
			
  $.get(ajax,
  function(theMessage){
$('<div class="tooltip">'  + theMessage + '</div>').appendTo('body').fadeIn('fast');});

 
 }else{
			
	    var theMessage = $(this).attr('content');
	    $('<div class="tooltip">' + theMessage + '</div>').appendTo('body').fadeIn('fast');
		}
		
		$(this).bind('mousemove', function(e){
			$('div.tooltip').css({
				'top': e.pageY - ($('div.tooltip').height() / 2) - 5,
				'left': e.pageX + 15
			});
		});
	}).bind('mouseout', function(){
		$('div.tooltip').fadeOut('fast', function(){
			$(this).remove();
		});
	});
						   });

</script>

<style>
.tooltip{
	position:absolute;
	width:320px;
	background-image:url(tip-bg.png);
	background-position:left center;
	background-repeat:no-repeat;
	color:#FFF;
	padding:5px 5px 5px 18px;
	font-size:12px;
	font-family:Verdana, Geneva, sans-serif;
	}
	
.tooltip-image{
	float:left;
	margin-right:5px;
	margin-bottom:5px;
	margin-top:3px;}	
	
	
	.tooltip span{font-weight:700;
color:#ffea00;}




li{
	margin-bottom:30px;}
	#imagcon{
		overflow:hidden;
		float:left;
		height:100px;
		width:100px;
		margin-right:5px;
	}
	#imagcon img{
		max-width:100px;
	}
	#wrapper{
		margin:0 auto;
		width:500px;
		margin-top: 99px;
	}
</style>
</head>
<body >
<div  style="margin:0px auto;max-width:1024px;">
  <div id="amazingslider-1" style="display:block;position:relative;margin:0px auto 30px;">
    <ul class="amazingslider-slides" style="display:none;">
      <li><?php
include('../connection.php');

$result = mysql_query("SELECT * FROM imageslider WHERE id ORDER BY id DESC");
while($row = mysql_fetch_array($result))
{
	echo '<li><img src="homepage../'.$row['image'].'" alt="" /></li>'
	
?> 
  </li><?php }?>
      </ul>
  </div>
</div>
<hr />
<h1>Latest Product</h1>
<hr />
<center><img src='picture/Yamaha-logo.png' width="183" height="59"  id="image" style="width:200px;height:56px;" border="0" /></center>

 <table  align="center">

               <tr style="height:200px; width:820px">

               <?php

			 include('connection.php');

			 $query="SELECT * FROM product WHERE brand='YAMAHA' ORDER BY id DESC limit 0,5";

			 $result=mysql_query($query);

			 $i=1;

				while($row=mysql_fetch_array($result))

				{

                 ?>

                   <td  style=" width:255px; border:0px solid #0000CC;"align="center" >

                    <div style="height:300px; width:230px; float:left;border:1px solid #B9B9B9;border-radius:10px; margin-left:12px; margin-top:20px;"> 

                    <div style="height:170px; width:230px; float:left;border:0px solid #000000;border-radius:15px;" align="center"><a  href="index.php?page=specificationProductCustomer&id=<?php echo $row['id'];?>" style="text-decoration:none;"><img src="images/<?php echo $row['image'];?>" height="170" width="180"></a></div> 

                    <div style="height:120px; width:215px; float:left;border:0px solid #000000;border-radius:15px; margin-left:8px;">

                    <table border="0">

                    <tr><td style="color:#990000; height:30px; width:210px;" align="center" colspan="3"><font style="color:#F30"><b><?php echo $row['title'];?></b></font></td></tr>                   

                    <tr><td width="95" height="20"><b>Brand:</td><td width="111" colspan="2" style=" margin-left:5px;"><?php echo $row['brand'];?></td></tr>

                    <tr><td height="20"><strong>Price:&nbsp;</strong></td><td><?php echo $row['price'];?> </td></tr>

                    </table>



                   <div><table border="0" width="220">  <tr style="border:0px solid #000000; height:30px;" align="center"><td colspan="2"> <a href="index.php?page=specificationProductCustomer&id=<?php echo $row['id'];?>" style="text-decoration:none;"><input type="button" name="buynow" value="DETAILS" style="height:25px; width:75px; background-color:#F30; border:0px solid #333333; border-radius:5px; color:#FFFFFF;"></a></td>

                           </tr>

                    </table></div>

          </div>

             

                     </div>

                  </td>

                  <?php if($i%4==0)

	                {?>

   </tr>

                      

                   <?php	

	           }

	

	                     $i=$i+1;

	                         }

                                  ?>

</table>

<hr />

<center><img src='picture/sym-logo.png' width="183" height="59"  id="image" style="width:200px;height:56px;" border="0" /></center>

<table  align="center">

               <tr style="height:200px; width:820px">

               <?php

			 include('connection.php');

			 $query="SELECT * FROM product WHERE brand='SYM' ORDER BY id DESC limit 0,5";

			 $result=mysql_query($query);

			 $i=1;

				while($row=mysql_fetch_array($result))

				{

                 ?>

                   <td  style=" width:255px; border:0px solid #0000CC;"align="center" >

                    <div style="height:300px; width:230px; float:left;border:1px solid #B9B9B9;border-radius:10px; margin-left:12px; margin-top:20px;"> 

                    <div style="height:170px; width:230px; float:left;border:0px solid #000000;border-radius:15px;" align="center"><a  href="index.php?page=specificationProductCustomer&id=<?php echo $row['id'];?>" style="text-decoration:none;"><img src="images/<?php echo $row['image'];?>" height="170" width="180"></a></div> 

                    <div style="height:120px; width:215px; float:left;border:0px solid #000000;border-radius:15px; margin-left:8px;">

                    <table border="0">

                    <tr><td style="color:#990000; height:30px; width:210px;" align="center" colspan="3"><font style="color:#F30"><b><?php echo $row['title'];?></b></font></td></tr>                   

                    <tr><td width="95" height="20"><b>Brand:</td><td width="111" colspan="2" style=" margin-left:5px;"><?php echo $row['brand'];?></td></tr>

                    <tr><td height="20"><strong>Price:&nbsp;</strong></td><td><?php echo $row['price'];?> </td></tr>

                    </table>



                   <div><table border="0" width="220">  <tr style="border:0px solid #000000; height:30px;" align="center"><td colspan="2"> <a href="index.php?page=specificationProductCustomer&id=<?php echo $row['id'];?>" style="text-decoration:none;"><input type="button" name="buynow" value="DETAILS" style="height:25px; width:75px; background-color:#F30; border:0px solid #333333; border-radius:5px; color:#FFFFFF;"></a></td>

                           </tr>

                    </table></div>

          </div>

             

                     </div>

                  </td>

                  <?php if($i%4==0)

	                {?>

                         </tr>

                      

                   <?php	

	           }

	

	                     $i=$i+1;

	                         }

                                  ?>

	  </table>

<hr />

<center><img src='picture/honda-logo.png' width="183" height="59"  id="image" style="width:200px;height:56px;" border="0" /></center>

<table  align="center">

               <tr style="height:200px; width:820px">

               <?php

			 include('connection.php');

			 $query="SELECT * FROM product WHERE brand='HONDA' ORDER BY id DESC limit 0,5";

			 $result=mysql_query($query);

			 $i=1;

				while($row=mysql_fetch_array($result))

				{

                 ?>

                   <td  style=" width:255px; border:0px solid #0000CC;"align="center" >

                    <div style="height:300px; width:230px; float:left;border:1px solid #B9B9B9;border-radius:10px; margin-left:12px; margin-top:20px;"> 

                    <div style="height:170px; width:230px; float:left;border:0px solid #000000;border-radius:15px;" align="center"><a  href="index.php?page=specificationProductCustomer&id=<?php echo $row['id'];?>" style="text-decoration:none;"><img src="images/<?php echo $row['image'];?>" height="170" width="180"></a></div> 

                    <div style="height:120px; width:215px; float:left;border:0px solid #000000;border-radius:15px; margin-left:8px;">

                    <table border="0">

                    <tr><td style="color:#990000; height:30px; width:210px;" align="center" colspan="3"><font style="color:#F30"><b><?php echo $row['title'];?></b></font></td></tr>                   

                    <tr><td width="95" height="20"><b>Brand:</td><td width="111" colspan="2" style=" margin-left:5px;"><?php echo $row['brand'];?></td></tr>

                    <tr><td height="20"><strong>Price:&nbsp;</strong></td><td><?php echo $row['price'];?> </td></tr>

                    </table>



                   <div><table border="0" width="220">  <tr style="border:0px solid #000000; height:30px;" align="center"><td colspan="2"> <a href="index.php?page=specificationProductCustomer&id=<?php echo $row['id'];?>" style="text-decoration:none;"><input type="button" name="buynow" value="DETAILS" style="height:25px; width:75px; background-color:#F30; border:0px solid #333333; border-radius:5px; color:#FFFFFF;"></a></td>

                           </tr>

                    </table></div>

          </div>

             

                     </div>

                  </td>

                  <?php if($i%4==0)

	                {?>

                         </tr>

                      

                   <?php	

	           }

	

	                     $i=$i+1;

	                         }

                                  ?>

	  </table>

<hr />

<center><img src='picture/Modenas-logo.png' width="183" height="59"  id="image" style="width:200px;height:56px;" border="0" /></center>

<table  align="center">

               <tr style="height:200px; width:820px">

               <?php

			 include('connection.php');

			 $query="SELECT * FROM product WHERE brand='MODENAS' ORDER BY id DESC limit 0,5";

			 $result=mysql_query($query);

			 $i=1;

				while($row=mysql_fetch_array($result))

				{

                 ?>

                   <td  style=" width:255px; border:0px solid #0000CC;"align="center" >

                    <div style="height:300px; width:230px; float:left;border:1px solid #B9B9B9;border-radius:10px; margin-left:12px; margin-top:20px;"> 

                    <div style="height:170px; width:230px; float:left;border:0px solid #000000;border-radius:15px;" align="center"><a  href="index.php?page=specificationProductCustomer&id=<?php echo $row['id'];?>" style="text-decoration:none;"><img src="images/<?php echo $row['image'];?>" height="170" width="180"></a></div> 

                    <div style="height:120px; width:215px; float:left;border:0px solid #000000;border-radius:15px; margin-left:8px;">

                    <table border="0">

                    <tr><td style="color:#990000; height:30px; width:210px;" align="center" colspan="3"><font style="color:#F30"><b><?php echo $row['title'];?></b></font></td></tr>                   

                    <tr><td width="95" height="20"><b>Brand:</td><td width="111" colspan="2" style=" margin-left:5px;"><?php echo $row['brand'];?></td></tr>

                    <tr><td height="20"><strong>Price:&nbsp;</strong></td><td><?php echo $row['price'];?> </td></tr>

                    </table>



                   <div><table border="0" width="220">  <tr style="border:0px solid #000000; height:30px;" align="center"><td colspan="2"> <a href="index.php?page=specificationProductCustomer&id=<?php echo $row['id'];?>" style="text-decoration:none;"><input type="button" name="buynow" value="DETAILS" style="height:25px; width:75px; background-color:#F30; border:0px solid #333333; border-radius:5px; color:#FFFFFF;"></a></td>

                           </tr>

                    </table></div>

          </div>

             

                     </div>

                  </td>

                  <?php if($i%4==0)

	                {?>

                         </tr>

                      

                   <?php	

	           }

	

	                     $i=$i+1;

	                         }

                                  ?>

	  </table>

<hr />

<center><img src='picture/Demak-logo.png' width="179" height="47"  id="image" style="width:185px;height:47px;" border="0" /></center>

<table  align="center">

               <tr style="height:200px; width:820px">

               <?php

			 include('connection.php');

			 $query="SELECT * FROM product WHERE brand='DEMAK' ORDER BY id DESC limit 0,5";

			 $result=mysql_query($query);

			 $i=1;

				while($row=mysql_fetch_array($result))

				{

                 ?>

                   <td  style=" width:255px; border:0px solid #0000CC;"align="center" >

                    <div style="height:300px; width:230px; float:left;border:1px solid #B9B9B9;border-radius:10px; margin-left:12px; margin-top:20px;"> 

                    <div style="height:170px; width:230px; float:left;border:0px solid #000000;border-radius:15px;" align="center"><a  href="index.php?page=specificationProductCustomer&id=<?php echo $row['id'];?>" style="text-decoration:none;"><img src="images/<?php echo $row['image'];?>" height="170" width="180"></a></div> 

                    <div style="height:120px; width:215px; float:left;border:0px solid #000000;border-radius:15px; margin-left:8px;">

                    <table border="0">

                    <tr><td style="color:#990000; height:30px; width:210px;" align="center" colspan="3"><font style="color:#F30"><b><?php echo $row['title'];?></b></font></td></tr>                   

                    <tr><td width="95" height="20"><b>Brand:</td><td width="111" colspan="2" style=" margin-left:5px;"><?php echo $row['brand'];?></td></tr>

                    <tr><td height="20"><strong>Price:&nbsp;</strong></td><td><?php echo $row['price'];?> </td></tr>

                    </table>



                   <div><table border="0" width="220">  <tr style="border:0px solid #000000; height:30px;" align="center"><td colspan="2"> <a href="index.php?page=specificationProductCustomer&id=<?php echo $row['id'];?>" style="text-decoration:none;"><input type="button" name="buynow" value="DETAILS" style="height:25px; width:75px; background-color:#F30; border:0px solid #333333; border-radius:5px; color:#FFFFFF;"></a></td>

                           </tr>

                    </table></div>

          </div>

             

                     </div>

                  </td>

                  <?php if($i%4==0)

	                {?>

                         </tr>

                      

                   <?php	

	           }

	

	                     $i=$i+1;

	                         }

                                  ?>

	  </table>



<hr />

<p>&nbsp;</p>
	
</body> 
</html>
