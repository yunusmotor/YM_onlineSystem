<?php
include("../connection.php");

  $username = $_POST['username'];
  $password = $_POST['password'];

  $username = stripslashes($username);
  $password = stripslashes($password);
  $username = mysql_real_escape_string($username);
  $password = mysql_real_escape_string($password);

  $query = "SELECT * FROM staff WHERE staff_username= '$username' AND loginPass='$password'";
  $result = mysql_query($query);

  $count = mysql_num_rows($result);//counting table rows

  if($count==1)
  {
	session_start();
		$_SESSION['staff_username']=$username;
		
		while ($row = mysql_fetch_array($result))
		{
			if($row['level']==1){
      		echo "<script>
	  alert('Login succesful');
	  window.location = '../Admin/homeAdmin.php?page=review_admin';
	  </script>
	  ";
			
    		}
			elseif($row['level']==2){
      		echo "<script>
	  alert('Login succesful');
	  window.location = '../Admin/homeWorker.php?page=review_worker';
	  </script>
	  ";
			
    		}
			else
    		{
			session_start();
			$_SESSION['staff_username']=$username;
      		header("Location:index.html");
    		}
			}  	
			
}
else{
	  echo "<script>
	  alert('Login Failed!!!');
	  window.location = '../homepage/loginForm.html';
	  </script>
	  ";
	}
?>
