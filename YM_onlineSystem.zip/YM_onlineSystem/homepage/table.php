<?php

include_once("../connection.php");
     

$getid=$_REQUEST["id"];
$query="SELECT * FROM customer WHERE NOPlateMotor='$getid'";
$result=mysql_query("SELECT * FROM deposit WHERE NOPlateMotor");
$result=mysql_query($query);
$row=mysql_fetch_array($result);


          
	
 
	
      
?>


 <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
 <style type="text/css">
 #price {margin-top: 5px;
}
#title {margin-top: 5px;
}


a:hover {
	text-decoration: underline;
}


a:visited {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
 </style>
<body>

<table width="921" border="0">

  <tr>
    <td width="915">
     <div class="">
        <div class="b">Deposit By Monthly Payment</div>
        <table width="681" border="0">
          <tr>
            <td width="126"><span class="f24">Amount Cash</span></td>
            <td width="545"><span class="f24">
             RM <?php echo $row['amounthCash'] ?>            </span></td>
          </tr>
          <tr>
            <td><span class="f24">Deposit</span></td>
            <td><span class="f24">
             RM <?php echo $row['deposit'] ?>            </span></td>
          </tr>
          <tr>
            <td><span class="f24">Permonthly</span></td>
            <td>              <span class="f24"><?php echo $row['paymentMonthly'] ?>              X 
                <?php echo $row['month'] ?> Month            </span></td>
          </tr>
        </table>
        <br />
        <p>&nbsp;  </p>
     
        <table width="87%"  class="table table-striped table-bordered">
          <thead>
            <tr>
              <th width="7%" bgcolor="#FFCC00">Monthly</th>
              <th width="14%" bgcolor="#FFCC00">Plate No.</th>
              <th width="17%" bgcolor="#FFCC00">Date</th>
              <th width="15%" bgcolor="#FFCC00">Amount</th>
            </tr>
          </thead>
          <tbody>
            <?php 
							$query=mysql_query("select * from deposit where NOPlateMotor='$getid' ORDER BY perMonth DESC")or die(mysql_error());
							while($row=mysql_fetch_array($query)){
							$id=$row['no_Payment'];
							?>
            <tr id="row1">
              <td bgcolor="#CCCCCC"><input type="hidden" name="id" value="<?php echo $row['no_Payment'] ?>"/>  <center>              <?php echo $row['perMonth'] ?></center></td>
              <td bgcolor="#CCCCCC"><center><?php echo $row['NOPlateMotor'] ?></center></td>
              <td bgcolor="#CCCCCC"><center><?php echo $row['date'] ?></center></td>
              <td bgcolor="#CCCCCC"><center>RM&nbsp;&nbsp;<?php echo $row['amount'] ?></center></td>
            </tr>
            <?php } ?>
          </tbody>
        </table>
          
        
        <?php
                            $result = mysql_query("SELECT sum(perMonth) FROM deposit WHERE NOPlateMotor='$getid'") or die(mysql_error());
                            while ($rows = mysql_fetch_array($result)) {
                                ?>
        <?php }
                            ?>
                            
        <?php
                 
								
                            $result1 = mysql_query("SELECT sum(amount) FROM deposit WHERE NOPlateMotor='$getid'") or die(mysql_error()); 
							
                            while ($rows1 = mysql_fetch_array($result1)) {
                                ?>
                           
        <div class="pull-right">
          <div class="span">
            <div class="alert alert-info"><i class="icon-credit-card icon-large"></i>&nbsp;Total Amount : RM&nbsp;<?php echo $rows1['sum(amount)']; ?></div>
          </div>
        </div>
         
        
                              <?php
                 
								
                            $result2 = mysql_query("SELECT paymentMonthly,month FROM customer WHERE NOPlateMotor='$getid'") or die(mysql_error()); 
							
                            while ($rows2 = mysql_fetch_array($result2)) {
                                ?>
                            <div class="pull-right">
          <div class="span">
            <div class="alert alert-info"><i class="icon-credit-card icon-large"></i>&nbsp;Balance : RM&nbsp;<?php  $balance=$rows2['paymentMonthly']*$rows2['month'];
			$amount=$rows1['sum(amount)'];
			$total=$balance - $amount;
			echo $total;
		?></div>
          </div>
        </div> <?php }?> <?php }
                            ?>
  </div>
      <p>&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;  &nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp;<br />
      </p>
    </form></td>
  </tr>
</table>
<br>
</body>
</html>
