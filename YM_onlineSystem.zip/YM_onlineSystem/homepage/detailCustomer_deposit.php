<?php
include("../connection.php");

	$getId=$_REQUEST["id"];
    $query="SELECT * FROM customer WHERE NOPlateMotor='$getId'";
	$result=mysql_query($query);
	 
//dialog edit detail customer
	if($_GET['edit']=="true"){
 		echo"<div id='jQueryDialog1' title='Edit Detail Customer'>";
 		include("../Admin/page/edit_customer.php");
 		echo "</div>";
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.font {
	text-align: center;
	color: #F30;
}
.font {
	text-align: center;
}
.font1 {	text-align: center;
	color: #F30;
}
.font table tr td {
	text-align: center;
}
</style>
</head>

<body><?php
while($row=mysql_fetch_array($result))
   {?> 
<table width="736" height="235" border="0" align="center">
      <tr>
        <td width="798"><span style="text-align:center; word-break:break-all; width:100px;"><font size="+3"><?php echo $row ['NOPlateMotor']; ?></font></span></td>
        <td width="337">&nbsp;</td>
        <td width="257">&nbsp;</td>
      </tr>
      <tr>
        <td height="118" class="font">
           
          <table width="200" border="0">
  <tr>
    <td bgcolor="#999999"><img src= "homepage../<?php
		  
 echo $row['inFront_IC']; ?>" alt="" width="276" height="150" style="border:1px solid #333333;"/></td>
  </tr>
  <tr>
    <td>In front &quot;IC&quot; </td>
  </tr>
  <tr>
    <td height="41">&nbsp;</td>
  </tr>
  <tr>
    <td bgcolor="#999999"><img src= "homepage../<?php
		  
 echo $row['Rear_IC']; ?>" alt="" width="276" height="150" style="border:1px solid #333333;"/></td>
  </tr>
  <tr>
    <td></blockquote>
      </blockquote>
      <span class="font1">Rear &quot;IC&quot;</span></td>
  </tr>
</table>
<p></a><br />
</p>
          <p><br />
          </p></td>
        <td><table width="399" border="0">
          <tr>
            <td width="51" height="60"></td> <td width="183" height="60"><strong>IC Number:</strong></td>
            <td width="151"><span style="text-align:center; word-break:break-all; width:100px;">
           <?php echo $row ['ICNumber_Cust']; ?></span></td>
          </tr>
          <tr>
            <td width="51" height="60"></td><td height="42"><strong>Customer Name:</strong></td>
             <td><span style="text-align:center; word-break:break-all; width:100px;">
              <?php echo $row ['Name_Cust']; ?> 
            </span></td>
          </tr>
          <tr>
         <td width="51" height="60"></td>   <td height="45"><strong>Contact Number:</strong></td>
             <td><span style="text-align:center; word-break:break-all; width:100px;">
               <?php echo $row ['ContactNO_Cust']; ?> 
            </span></td>
          </tr>
          <tr>
          <td width="51" height="60"></td>  <td height="44"><strong>Address:</strong></td>
             <td><span style="text-align:center; word-break:break-all; width:100px;">
              <?php echo $row ['Address_Cust']; ?> 
            </span></td>
          </tr>
          <tr>
        <td width="51" height="60"></td>    <td height="45"><strong>Product Suplier Name</strong></td>
             <td><span style="text-align:center; word-break:break-all; width:100px;">
           <?php echo $row ['ProductSuplierName']; ?>  
            </span></td>
          </tr>
          <tr>
           <td width="51" height="60"></td> <td height="52"><strong>Type Motor</strong></td>
             <td><span style="text-align:center; word-break:break-all; width:100px;">
           <?php echo $row ['TypeMotor']; ?> 
            </span></td>
          </tr>
          <tr>
           <td width="51" height="60"></td> <td height="59"><strong>No. Engine Motor</strong></td>
             <td><span style="text-align:center; word-break:break-all; width:100px;">
             <?php echo $row ['No_EngineMotor']; ?>  
            </span></td>
          </tr>
          <tr>
        <td width="51" height="60"></td>    <td height="41"><strong>ColourMotor</strong></td>
             <td><span style="text-align:center; word-break:break-all; width:100px;">
            <?php echo $row ['ColourMotor']; ?> 
             </span></td>
          </tr>
         
        </table></td>
        <td></td>
      </tr>
</table><?php }?>
</body>
</html>
