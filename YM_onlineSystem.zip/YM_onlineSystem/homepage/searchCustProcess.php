<?php
include ("connection.php");
/*$mysql_hostname = "localhost";
$mysql_user = "root";
$mysql_password = "";
$mysql_database = "data";
$prefix = "";
$bd = mysql_connect($mysql_hostname, $mysql_user, $mysql_password) or die("Could not connect database");
mysql_select_db($mysql_database, $bd) or die("Could not select database"); */
$cari=$_POST["PlatField"];
$caricari=$_POST["ICField"];

$query= "SELECT * FROM customer WHERE NOPlateMotor='$cari' AND ICNumber_Cust='$caricari'";
$result=mysql_query($query);
$count=mysql_num_rows($result);

if($count==0){
echo "<script>
	alert (' No Data Found, Try Again ');
	window.location = '?page=CustomerService';
	</script>";
}
else
{
$row=mysql_fetch_array($result);

echo "<script>
	alert (' Data Found ');
	window.location = '?page=ViewCustomerInfo&id=$row[NOPlateMotor]';
	</script>";
}
?>