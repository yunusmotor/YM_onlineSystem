<?php
include_once("../connection.php");
session_start();
ob_start();
if(!isset($_SESSION['staff_username'])){
    
	die();
}

	   $sql = "SELECT * FROM staff WHERE staff_username='".$_SESSION['staff_username']."'";
        
        $query = mysql_query($sql)
                    or die(mysql_error());
                    
        $results = mysql_fetch_array($query);
	
?>