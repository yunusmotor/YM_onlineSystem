<?php
include ("session.php");
include ("connection.php");
session_start();
$nofail=$_REQUEST["id"];
$cari=$_POST["pentadbircari"];
?>
<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	visibility:visible;
	left:135px;
	top:56px;
	width:1067px;
	height:1199px;
	z-index:1;
	background-color: #FF8041;
}
.style1 {
	font-family: Georgia, "Times New Roman", Times, serif;
	font-size: 36px;
}
body {
	background-color: #FFFFFF;
	background-image: url(interface/Red-Strip-Black-Wallpaper-HD.jpg);
}
#Layer2 {
	position:absolute;
	left:268px;
	top:335px;
	width:804px;
	height:444px;
	z-index:2;
}
#Layer3 {
	position:absolute;
	left:2px;
	top:1047px;
	width:1064px;
	height:159px;
	z-index:2;
}
#Layer4 {
	position:absolute;
	left:-19px;
	top:799px;
	width:1068px;
	height:124px;
	z-index:2;
}
#Layer5 {
	position:absolute;
	left:154px;
	top:317px;
	width:1035px;
	height:65px;
	z-index:3;
}
-->
</style>
<title>Paparan Permohonan</title><div id="Layer1"><head>
  <div align="center"><img src="JBPM.jpg" height="200" width="200" align="right"><img src="lambangmalaysia.jpg" height="200" width="200" align="left"><br>
    <strong><span class="style1">SISTEM SEMAKAN KELULUSAN PELAN JBPM
    </span></div>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p align="center"><a href="index.php"><img src="Capture.PNG" width="146" height="37" border="0" /></a><a href="LoginForm.php"><img src="1PNG.PNG" width="146" height="37" border="0" /></a><a href="semakanstatuspelan.php"><img src="3.PNG" width="146" height="37" border="0" /></a><img src="4.PNG" width="146" height="37" /></p>
  <p align="center">&nbsp;</p>
  <p align="center">&nbsp;</p>
  <p><br />
  </p>
  <form id="form1" name="form1" method="post" action="pentadbir.php">
    <label>
      <div align="center">
        <input type="submit" name="Submit" value="KEMBALI" />
        </div>
    </label>
  </form>
  <p>&nbsp; </p>
</div>
<div id="Layer5">
  <div align="center"><?php
$query= "SELECT * FROM pelan WHERE noFail='$nofail'";
$result=mysql_query($query);
$count=mysql_num_rows($result);
echo "<Table width='50%' border='1' align='center'>";
		echo "<tr>";
		 echo "<td align='center'><b>NO FAIL</b></td>";
		 echo "<td align='center'><b>NAMA PROJEK</b></td>";
		 echo "<td align='center'><b>STATUS</b></td>";
		 echo "</tr>";
if($count==0)
{echo "no record found";}
else {
		while($row = mysql_fetch_array($result))
		{
		echo "<tr>";
		echo "<td align='center'>".$row[noFail]."</td>";
		echo "<td align='center'>".$row[namaProjek]."</td>";
		echo "<td align='center'>".$row[statusPelan]."</td>";
		echo "<td align='center'><a href='maklumatPermohonan.php?id=$row[noFail]'\">Maklumat Penuh</a></td>";
		echo "<td align='center'><a href='deleteProses.php?id=$row[noFail]'onclick=\"return confirm('Anda pasti untuk PADAM No Fail $row[noFail] projek $row[namaProjek]?')\">Padam</a></td>";
		echo "</tr>";
		}
	}
?>
</div>
</div>
<br />

    