<?php
include "connection.php";

$noID=$_POST["txtID"];
$username=$_POST["txtUsername"];
$fullname=$_POST["txtFullName"];
$phoneno=$_POST["txtPhoneNo"];
$gender=$_POST["radio"];
$noIC=$_POST["txtICno"];
$address=$_POST["txtAddress"];
$password=$_POST["txtConfirmPass"];

$query="INSERT INTO staff(staff_id, staff_username, staff_name, staff_no, staff_gender, staff_address, staff_ic, loginPass, level)
VALUES ('$noID','$username','$fullname','$phoneno','$gender','$address','$noIC','$password',2)";
$result=mysql_query($query) or die(mysql_error());

header('Location;index.html');
?>