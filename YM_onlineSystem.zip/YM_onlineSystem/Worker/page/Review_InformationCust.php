<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form name="TambahMotor" method="post" action="../modData.php">
	<br>
    <br>
    <br>
  <center>
    <h1>Tambah Motor </h1></center>
  <table width="397" height="186" border="0" class="editMotor" >
    <tr>
      <td width="103">Kode Motor</td>
      <td width="278"><label for="txtKodeMotor"></label>
      <input name="txtKodeMotor" type="text" id="txtKodeMotor" value="<?php echo $data['KodeMotor']; ?>"></td>
    </tr>
    <tr>
      <td>Merek</td>
      <td><input name="txtMerek" type="text" id="txtMerek"></td>
    </tr>
    <tr>
      <td>Warna</td>
      <td><input name="txtWarna" type="text" id="txtWarna"></td>
    </tr>
    <tr>
      <td>Harga</td>
      <td><input name="txtHarga" type="text" id="txtHarga"></td>
    </tr>
    <tr>
      <td colspan="2" align="center">         <input type="submit" name="btn_simpan" id="button" value="Simpan" class="btn_simpan"></td>
     
    </tr>
  </table>
</form>
</body>
</html>
