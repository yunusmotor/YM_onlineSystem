<?php

include("function.php");
include("connection.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>YUNUS MOTOR ONLINE SYSTEM</title>
<link rel='shortcut icon' href='picture/logoym.png' />
	<link rel="stylesheet" href="style.css">
      <link rel="stylesheet" href="homepage/css/style.css">
      <link rel="stylesheet" href="homepage/css/clndr.css" type="text/css" />
      <!----Calender -------->
			<link rel="stylesheet" href="homepage/css/clndr.css" type="text/css" />
			<!----End Calender -------->
  <script src="homepage/css/login.js"></script>
<script type="text/javascript" src="homepage/sliderengine/jquery.js"></script>
<script type="text/javascript" src="homepage/sliderengine/jquery.hislider.js"></script>
<script src="homepage/js/underscore-min.js" type="text/javascript"></script>
<script src= "homepage/js/moment-2.2.1.js" type="text/javascript"></script>
<script src="homepage/js/clndr.js" type="text/javascript"></script>
<script src="homepage/js/site.js" type="text/javascript"></script>
<script src="homepage/js/jquery.min.js"></script>

</style>

    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/main.css">
    <style type="text/css">
    body {
	background-image: url(picture/black-white-background-3.jpg);
	background-repeat: no-repeat;
}
    </style>
    <script src="//cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.min.js"></script>
</head>

<body>

<header>
            <div class="clearfix">
                <div class="column full">
                    <table width="1373" height="203" border="0">
                      <tr>
                        <td width="98" height="17">&nbsp;</td>
                        <td width="144">&nbsp;</td>
                        <td width="1117"><table width="1039" border="0">
                          <tr>
                            <td width="728">&nbsp;</td>
                            <td width="52"><img src="picture/Yamaha-logo.png" width="54" height="25" alt="logoyamaha" /></td>
                            <td width="56"><img src="picture/Sym-logo.png" width="58" height="23" alt="logosym" /></td>
                               <td width="65"><img src="picture/Honda-logo.png" width="67" height="24" alt="logohonda" /></td>
                                  <td width="55"><img src="picture/Modenas-logo.png" width="57" height="39" alt="logomodenas" /></td>
                                     <td width="57"><img src="picture/Demak-logo.png" width="59" height="20" alt="logoyamaha" /></td>
                          </tr>
                        </table></td>
                      </tr>
                      <tr>
                        <td height="150"></td>
                        <td><a href="?page=page"><img src="picture/logoym.png" alt="" width="142" height="131" /></a></td>
                        <td><img src="picture/nameSystem.png" alt="" width="837" height="84" /></td>
                      </tr>
                      <tr>
                        <td height="22">&nbsp;</td>
                        <td>&nbsp;</td>
                        <td><table width="1047" border="0">
                          <tr>
                            <td width="729" height="18">&nbsp;</td>
                            <td width="308"><?php ym_getMenu(); ?></td>
                          </tr>
                        </table></td>
                      </tr>
                    </table>
                  
              </div>
            </div>
        </header>

 <main>
            
           


<div  class="">
  <div class="">
  
    <table width="1415" height="22" border="0">
      <tr>
        <td width="141" height="18">&nbsp;</td>
        <td width="981"><?php ym_getPage($_REQUEST['page']); ?></td>
        <td width="279">&nbsp;</td>
      </tr>
    </table>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
</div></div>
</div>
<tr><td width="115" height="0" ><tr><div style="clear:both;height:90px;width:100%">
  <div class="main-wrap"> <center>
</center></div></div><p>&nbsp;</p></body></tr></td>
           <td width="924" bgcolor="#34495E"></td></tr>
           <tr><td width="924" bgcolor="#34495E"></td><td width="924" bgcolor="#34495E"><div></td></tr>
          </table>
        </div> 
         
    
          
      
        
  </div>
      <p>&nbsp;</p>
    </div>
      </p>
    </div>              
  		    </form></div>
             </div>
                </div>

            </section>

        </main>
            <footer id="footer">
           
                
                <div class="clearfix">
                    <div class="column full">
                        <p>Copyright &copy; 2017 YUNUS MOTOR ONLINE SYSTEM. All Rights Reserved | Design by Student Politechnic</p>
                        </p>
                    </div>
                </div>
        </footer>
<script src="//cdnjs.cloudflare.com"></script>
<script src="footer-reveal.min.js"></script>
<script src="main.js"></script>

<script>
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

      ga('create', 'UA-48617559-4', 'auto');
      ga('send', 'pageview');

    </script>
         
</body>
</html>