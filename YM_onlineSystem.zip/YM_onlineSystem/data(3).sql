-- phpMyAdmin SQL Dump
-- version 4.5.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 23, 2017 at 12:33 AM
-- Server version: 5.7.11
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `data`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `NOPlateMotor` varchar(20) NOT NULL,
  `ICNumber_Cust` varchar(40) NOT NULL,
  `Name_Cust` varchar(30) NOT NULL,
  `genderCust` varchar(20) NOT NULL,
  `ContactNO_Cust` int(15) NOT NULL,
  `Address_Cust` text NOT NULL,
  `inFront_IC` varchar(50) NOT NULL,
  `Rear_IC` varchar(50) NOT NULL,
  `ProductSuplierName` varchar(30) NOT NULL,
  `TypeMotor` varchar(20) NOT NULL,
  `No_EngineMotor` varchar(20) NOT NULL,
  `ColourMotor` varchar(30) NOT NULL,
  `amounthCash` varchar(50) NOT NULL,
  `paymentMonthly` varchar(300) NOT NULL,
  `deposit` varchar(20) NOT NULL,
  `month` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`NOPlateMotor`, `ICNumber_Cust`, `Name_Cust`, `genderCust`, `ContactNO_Cust`, `Address_Cust`, `inFront_IC`, `Rear_IC`, `ProductSuplierName`, `TypeMotor`, `No_EngineMotor`, `ColourMotor`, `amounthCash`, `paymentMonthly`, `deposit`, `month`) VALUES
('QRS6049', '962131131132', 'Muhd Awang Baptista', 'Male', 1108288488, 'Jalan Selangau Indah, Selangau', '../Admin/page/photos/', '../Admin/page/photos/', 'Boon Siew Honda', 'Honda RS150', 'HD213121', 'Repsol Orange', '5552', '252/Month', '1000', '30 ( 2 1/2 Year )');

-- --------------------------------------------------------

--
-- Table structure for table `deposit`
--

CREATE TABLE `deposit` (
  `no_Payment` float NOT NULL,
  `perMonth` int(30) NOT NULL,
  `date` date NOT NULL,
  `amount` varchar(30) NOT NULL,
  `NOPlateMotor` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deposit`
--

INSERT INTO `deposit` (`no_Payment`, `perMonth`, `date`, `amount`, `NOPlateMotor`) VALUES
(2124, 1, '2017-03-23', '252', 'QRS6049'),
(2125, 2, '2017-03-24', '252', 'QRS6049');

-- --------------------------------------------------------

--
-- Table structure for table `imageslider`
--

CREATE TABLE `imageslider` (
  `id` int(30) NOT NULL,
  `namePicture` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `imageslider`
--

INSERT INTO `imageslider` (`id`, `namePicture`, `image`) VALUES
(13, 'Yunus Company', '../Admin/page/images/Slide1.PNG'),
(16, 'YAMAHA EGO SOLARIZ', '../Admin/page/images/slide_588318357ba5f.jpg'),
(17, 'YAMAHA Y15ZR', '../Admin/page/images/slide_5796d8ec679c1.jpg'),
(18, 'SYM SPORT RIDER 125i', '../Admin/page/images/Web banner-01.jpg'),
(19, 'MAP FROM SYM MOTORCYCLE', '../Admin/page/images/Web Slider - SYM Worldwide.jpg'),
(20, 'DEMAK EVO-Z 125R', '../Admin/page/images/EVO-Z-125R.png'),
(21, 'MODENAS MR1', '../Admin/page/images/modenas-kriss-mr1-1.jpg'),
(22, 'MODENAS GT-128', '../Admin/page/images/13264862_A1.jpg'),
(23, 'HONDA RS-150R', '../Admin/page/images/honda rs150r fb.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(12) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `title` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `Overview` text NOT NULL,
  `color1` varchar(100) NOT NULL,
  `color2` varchar(100) NOT NULL,
  `color3` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `brand`, `title`, `image`, `price`, `Overview`, `color1`, `color2`, `color3`) VALUES
(6, 'SYM', 'E-Bonus 110', '../Admin/page/photos/EBonus 2016.jpg', 'RM 4,900', '', '', '', ''),
(7, 'SYM', 'E-Smart 110', '../Admin/page/photos/Esmart.jpg', 'RM ????', '', '', '', ''),
(8, 'SYM', 'E-SR 110', '../Admin/page/photos/ESR.jpg', 'RM ????', '', '', '', ''),
(9, 'SYM', 'JET-Power 125', '../Admin/page/photos/JetPower.jpg', 'RM ????', '', '', '', ''),
(10, 'SYM', 'Bonus -SR 110', '../Admin/page/photos/NBonus 2016.jpg', 'RM ????', '', '', '', ''),
(11, 'SYM', 'SportBonus-SR 115', '../Admin/page/photos/Sport Bonus 115 SR.jpg', 'RM ????', '', '', '', ''),
(12, 'SYM', 'SportBonus-SR MC 115', '../Admin/page/photos/Sport Bonus SR MC.jpg', 'RM ????', '', '', '', ''),
(13, 'SYM', 'Sport Rider -125i', '../Admin/page/photos/Sport Rider 125i.jpg', 'RM ????', '', '', '', ''),
(16, 'YAMAHA', 'YAMAHA', '../Admin/page/picture/', 'RM ????', 'k,l.', '', '', ''),
(17, 'YAMAHA', '135LC-SUPER SPORT', '../Admin/page/photos/135LC SUPER SPORT.png', 'RM ????', '', '', '', ''),
(18, 'YAMAHA', 'LAGENDA 115Z', '../Admin/page/photos/LAGENDA115Z.png', 'RM ????', '', '', '', ''),
(19, 'YAMAHA', 'E115M', '../Admin/page/photos/E115M.png', 'RM ????', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staff_id` int(20) NOT NULL,
  `staff_username` varchar(25) NOT NULL,
  `staff_name` varchar(50) NOT NULL,
  `staff_no` varchar(20) NOT NULL,
  `staff_gender` varchar(10) NOT NULL,
  `staff_address` varchar(50) NOT NULL,
  `staff_email` varchar(30) NOT NULL,
  `staff_ic` varchar(30) NOT NULL,
  `loginPass` varchar(50) NOT NULL,
  `location` varchar(100) NOT NULL,
  `level` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `staff_username`, `staff_name`, `staff_no`, `staff_gender`, `staff_address`, `staff_email`, `staff_ic`, `loginPass`, `location`, `level`) VALUES
(1, 'M.Zulkhairi', 'MOHD ZULKHAIRI BIN YAUNUS', '0145756918', 'Male', 'NO. 194 KAMPUNG PANCHOR LAMA 96200 DARO SARAWAK', 'm.zulkhairi1994@gmail.com', '941018-13-6809', '1111', '../Admin/page/photos/zul.png', 1),
(2, 'YAUNUS', 'YAUNUS BIN HUSSEN', '0111111111', 'MALE', 'NO 194 KAMPUNG PANCHUR LAMA 96200,DARO SARAWAK', 'yaunushessen@gmail.com', '710402-13-5087', '1234', '', 1),
(16, 'worker1', 'Amizul', '12111', 'Male', 'Lot', 'amizulalias@gmail.com', '920628136539', 'worker1', '../Admin/page/photos/FB_IMG_1457436177591.jpg', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`NOPlateMotor`),
  ADD KEY `NOPlateMotor` (`NOPlateMotor`);

--
-- Indexes for table `deposit`
--
ALTER TABLE `deposit`
  ADD PRIMARY KEY (`no_Payment`),
  ADD KEY `NOPlateMotor` (`NOPlateMotor`);

--
-- Indexes for table `imageslider`
--
ALTER TABLE `imageslider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staff_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `deposit`
--
ALTER TABLE `deposit`
  MODIFY `no_Payment` float NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2127;
--
-- AUTO_INCREMENT for table `imageslider`
--
ALTER TABLE `imageslider`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `staff_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
