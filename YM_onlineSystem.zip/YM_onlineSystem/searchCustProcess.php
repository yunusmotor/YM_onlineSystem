<?php
include ("connection.php");
session_start();
$cari=$_POST["searchField"];
$cari=$_POST["ICNoField"];

$query= "SELECT * FROM customer WHERE NoPlateMotor='$searchField' AND ICNumber_Cust='ICNoField'";
$result=mysql_query($query);
$count=mysql_num_rows($result);

if($count==0){
echo "No Data Found.<br>";
echo "<a href='searchCustomer.html'>Try Again</a>";
}
else
{
$row=mysql_fetch_array($result);
header("location:ViewCustomerInfo.php?id=$row[noFail]");
}
?>