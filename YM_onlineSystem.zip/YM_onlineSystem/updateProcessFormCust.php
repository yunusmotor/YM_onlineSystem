<?php
session_start();
include ("connection.php");
$getid=$_REQUEST["id"];

$Name_Cust=$_POST["Name_Cust"];
$ICNumber_Cust=$_POST["ICNumber_Cust"];
$ContactNO_Cust=$_POST["txtnamaProjek"];
$NOPlateMotor=$_POST["NOPlateMotor"];
$No_EngineMotor=$_POST["No_EngineMotor"];
$TypeMotor=$_POST["TypeMotor"];
$ColorMotor=$_POST["ColorMotor"];
$Monthly_Payment=$_POST["Monthly_Payment"];
$Payment_Balance=$_POST["Payment_Balance"];
$ProductSuplierName=$_POST["ProductSuplierName"];

mysql_query("UPDATE customer SET'$Name_Cust','$ICNumber_Cust','$ContactNO_Cust','$NOPlateMotor','$No_EngineMotor','$TypeMotor','$ColorMotor','$Monthly_Payment','$Payment_Balance','$ProductSuplierName' WHERE NOPlateMotor=$getid");

header("location:viewFormCust.php");
?>